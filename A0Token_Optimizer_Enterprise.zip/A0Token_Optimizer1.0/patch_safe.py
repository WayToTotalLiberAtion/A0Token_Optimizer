import re

file_path = '/a0/usr/projects/skill/A0Token_Optimizer/A0Token_Optimizer1.0/scripts/llmlingua_core.py'
with open(file_path, 'r') as f:
    content = f.read()

# We will replace the compress_prompt call safely
pattern = r'result = self\._model\.compress_prompt\(.*?return_word_label=False,\s*\)'

replacement = """result = self._model.compress_prompt(
                normalized.split("\\n"),
                instruction="",
                question="",
                target_token=0,
                rate=rate,
                force_tokens=[],
                chunk_end_tokens=[],
                return_word_label=False,
                keep_first_sentence=False,
                keep_last_sentence=False
            )"""

new_content = re.sub(pattern, replacement, content, flags=re.DOTALL)

with open(file_path, 'w') as f:
    f.write(new_content)
