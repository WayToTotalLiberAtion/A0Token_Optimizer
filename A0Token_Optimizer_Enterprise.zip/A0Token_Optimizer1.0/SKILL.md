---
name: A0Token-Optimizer
version: 5.0.0
author: Agent Zero Developer
tags: [token-optimization, llmlingua2, compression, cost-reduction, agent-zero]
model: microsoft/llmlingua-2-xlm-roberta-large-meetingbank
license: MIT
---

# A0 Token Optimizer v5.0

**Enhanced LLMLingua2 Token Optimization Suite for Agent Zero**

Reduce LLM API costs by 40-90% with intelligent compression of BOTH input AND output tokens, plus image optimization and document compression — all while maintaining 85-98% quality retention.

## Overview

This skill provides a comprehensive token optimization pipeline that intercepts, analyzes, and compresses all token-consuming operations in Agent Zero:

- **INPUT tokens** (prompts, context, documents sent to LLM) → compressed before API call
- **OUTPUT tokens** (responses, logs, chain data) → compressed for storage/forwarding
- **Images** (vision API calls) → resized/recompressed to reduce vision tokens
- **Documents** (PDF, DOCX, TXT, etc.) → extracted and compressed
- **Conversation context** → graduated compression (old messages compressed more)

## Features

### Core Compression Engine
- **Multi-Pass Adaptive Compression** — Auto-tunes rate for optimal quality/compression balance
- **Content-Type Profiling** — Auto-detects code, prose, JSON, chat, system prompts and applies specialized strategies
- **Pre-Compression Normalization** — Free 10-30% reduction via whitespace/redundancy cleanup before ML compression
- **Semantic Chunking** — Splits text at natural boundaries for better coherence on long texts
- **Smart Caching** — Hash-based LRU cache with disk persistence for instant repeated compressions

### Token Direction Coverage
- **Input Token Optimization** — Compress prompts, context, and documents before sending to LLM
- **Output Token Optimization** — Compress LLM responses for storage, logging, and chain forwarding
- **Both directions reduce API costs** — Input tokens + output tokens (typically 3x more expensive)

### Image Optimization
- **Automatic resizing** to optimal API dimensions
- **Quality-aware recompression** (JPEG/WebP)
- **Format conversion** (BMP, TIFF → efficient formats)
- **Token estimation** based on OpenAI vision tile system
- **Enabled by default**, configurable via welcome wizard or API

### Document Compression
- **Supported formats**: TXT, MD, HTML, CSV, JSON, XML, YAML, PDF, DOCX, RTF
- **Auto-extraction** from binary formats (PDF, Office)
- **Batch processing** for entire directories

### Context Window Optimizer
- **Graduated compression** for conversation histories:
  - Recent 3 messages: uncompressed
  - Messages 4-10: light compression (50% rate)
  - Messages 11+: heavy compression (85% rate)
  - System prompt: configurable
- **Maximizes context window utilization** — the killer feature for long conversations

### Quality Assurance
- **Quality Reporter** with multi-metric analysis:
  - Word overlap ratio
  - Named entity retention
  - Key phrase (bigram) retention
  - Readability score comparison
  - Information density measurement
- **Quality grades** from A+ to F with recommendations

### Metrics & Cost Dashboard
- **Persistent tracking**: lifetime, daily, per-session stats
- **Cost estimation**: configurable $/1K tokens for any model
- **HTML dashboard** at `/dashboard` endpoint
- **Tracks**: input tokens saved, output tokens saved, image tokens saved, cache hits

### Agent Zero Integration
- **Transparent interception**: `compress_for_agent()` and `compress_response_for_agent()`
- **Image integration**: `optimize_image_for_agent()`
- **Document integration**: `optimize_document_for_agent()`
- **Context integration**: `optimize_context_for_agent()`
- **HTTP daemon or local fallback** — works both ways

## Installation

### Quick Start
```bash
bash INSTALL_AND_START.sh
```
This runs the **Welcome Wizard** (shows skill info, lets you configure image optimization), installs dependencies, and starts the daemon.

### Manual Installation
```bash
pip install -r requirements.txt
python3 scripts/welcome_wizard.py
bash service/control.sh start
```

### Docker
```bash
docker build -t a0-token-optimizer .
docker run -d -p 9199:9199 --name token-optimizer a0-token-optimizer
```

## Usage

### CLI Tools

#### Compress Text
```bash
# Direct text
python3 scripts/compress.py "Your long text here"

# From stdin
echo "Your text" | python3 scripts/compress.py

# Output tokens
python3 scripts/compress.py -d output "LLM response text"

# With JSON output and profile
python3 scripts/compress.py -j -p code "def function(): ..."
```

#### Compress Files
```bash
# Text file
python3 scripts/compress_file.py document.txt

# PDF document
python3 scripts/compress_file.py report.pdf

# Image
python3 scripts/compress_file.py photo.jpg

# With output path
python3 scripts/compress_file.py input.txt -o compressed.txt
```

#### Batch Compression
```bash
python3 scripts/compress_batch.py /path/to/files/ -o /path/to/output/ --recursive --include-images
```

#### Quality Testing
```bash
python3 scripts/test_quality.py
```

### HTTP API (Daemon)

#### Start/Stop
```bash
bash service/control.sh start|stop|restart|status|logs
```

#### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check |
| POST | `/compress` | Compress text (input/output) |
| POST | `/compress/output` | Compress output tokens |
| POST | `/compress/document` | Compress document file |
| POST | `/compress/image` | Optimize image |
| POST | `/compress/context` | Optimize conversation context |
| GET | `/stats` | Engine statistics + metrics |
| GET | `/dashboard` | HTML metrics dashboard |
| GET | `/config` | Current configuration |
| POST | `/config` | Update configuration |
| POST | `/shutdown` | Graceful shutdown |

#### Example API Calls

```bash
# Compress input text
curl -X POST http://127.0.0.1:9199/compress \
  -H "Content-Type: application/json" \
  -d '{"text": "Your text here", "direction": "input"}'

# Compress output text
curl -X POST http://127.0.0.1:9199/compress/output \
  -H "Content-Type: application/json" \
  -d '{"text": "LLM response here"}'

# Optimize image
curl -X POST http://127.0.0.1:9199/compress/image \
  -H "Content-Type: application/json" \
  -d '{"file_path": "/path/to/image.jpg"}'

# Compress document
curl -X POST http://127.0.0.1:9199/compress/document \
  -H "Content-Type: application/json" \
  -d '{"file_path": "/path/to/report.pdf"}'

# Optimize conversation context
curl -X POST http://127.0.0.1:9199/compress/context \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]}'

# Toggle image optimization
curl -X POST http://127.0.0.1:9199/config \
  -H "Content-Type: application/json" \
  -d '{"image_optimization": false}'
```

### Python API

```python
# Direct compression
from scripts.llmlingua_core import get_optimizer
opt = get_optimizer()
result = opt.compress_input("Your text", rate=0.5)
result = opt.compress_output("Response text", rate=0.7)

# Agent Zero integration
from service.prompt_interceptor import compress_for_agent, compress_response_for_agent
compressed_prompt = compress_for_agent("Long prompt text")
compressed_response = compress_response_for_agent("Long response text")

# Image optimization
from scripts.image_optimizer import get_image_optimizer
img_opt = get_image_optimizer()
result = img_opt.optimize("/path/to/image.jpg")

# Document compression
from scripts.document_optimizer import optimize_document
result = optimize_document("/path/to/report.pdf")

# Context optimization
from scripts.context_optimizer import optimize_messages
result = optimize_messages(messages_list, system_prompt="...")

# Quality analysis
from scripts.quality_reporter import analyze_quality
report = analyze_quality(original_text, compressed_text)
```

## Configuration

### Environment Variables
| Variable | Default | Description |
|----------|---------|-------------|
| `TOKEN_OPT_CACHE_DIR` | `/var/cache/a0-token-optimizer` | Base cache directory |
| `TOKEN_OPT_HOST` | `127.0.0.1` | Daemon bind address |
| `TOKEN_OPT_PORT` | `9199` | Daemon port |
| `TOKEN_OPT_RATE` | `0.5` | Default compression rate |
| `TOKEN_OPT_IMAGE_ENABLED` | `true` | Image optimization on/off |
| `TOKEN_OPT_DOC_ENABLED` | `true` | Document optimization on/off |
| `TOKEN_OPT_OUTPUT_ENABLED` | `true` | Output compression on/off |
| `TOKEN_OPT_OUTPUT_RATE` | `0.5` | Output compression rate |
| `TOKEN_OPT_ADAPTIVE` | `true` | Adaptive multi-pass on/off |
| `TOKEN_OPT_IMG_MAX_W` | `1024` | Max image width |
| `TOKEN_OPT_IMG_MAX_H` | `1024` | Max image height |
| `TOKEN_OPT_IMG_QUALITY` | `80` | Image compression quality |
| `TOKEN_OPT_WATCH_INTERVAL` | `5` | File watcher poll interval (s) |
| `TOKEN_OPT_COST_INPUT` | `0.01` | Cost per 1K input tokens ($) |
| `TOKEN_OPT_COST_OUTPUT` | `0.03` | Cost per 1K output tokens ($) |

### Runtime Configuration
Persistent user config saved to `$TOKEN_OPT_CACHE_DIR/user_config.json`.
Changeable via:
- Welcome wizard (first run)
- API: `POST /config {"image_optimization": false}`
- Direct edit of `user_config.json`

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Agent Zero                            │
│                                                         │
│  prompt_interceptor.py                                  │
│  ├── compress_for_agent()         (input tokens)        │
│  ├── compress_response_for_agent() (output tokens)      │
│  ├── optimize_image_for_agent()   (vision tokens)       │
│  ├── optimize_document_for_agent() (doc tokens)         │
│  └── optimize_context_for_agent() (context tokens)      │
│         │                                               │
│         ▼                                               │
│  ┌─── daemon.py (HTTP :9199) ◄── CLI tools ────┐       │
│  │    /compress, /compress/output               │       │
│  │    /compress/image, /compress/document        │       │
│  │    /compress/context, /dashboard              │       │
│  └─────────────┬────────────────────────────────┘       │
│                │                                        │
│         ┌──────┴──────┐                                 │
│         ▼             ▼                                 │
│  llmlingua_core   image_optimizer                       │
│  ├── normalizer   ├── resize                            │
│  ├── profiler     ├── recompress                        │
│  ├── chunker      └── token_estimate                    │
│  ├── cache                                              │
│  ├── adaptive     document_optimizer                    │
│  └── quality      ├── PDF extraction                    │
│                   ├── Office extraction                  │
│  context_optimizer└── compress pipeline                  │
│  ├── graduated                                          │
│  └── per-message  metrics_tracker                       │
│                   ├── lifetime stats                     │
│  output_compressor├── daily tracking                     │
│  ├── for_storage  └── cost estimation                    │
│  └── for_chain                                          │
└─────────────────────────────────────────────────────────┘
```

## File Structure

```
A0Token-Optimizer/
├── scripts/                    # Core modules & CLI tools
│   ├── config.py               # Centralized configuration (env + user prefs)
│   ├── normalizer.py           # Pre-compression text normalization
│   ├── profiler.py             # Content-type auto-detection
│   ├── chunker.py              # Semantic text chunking
│   ├── compression_cache.py    # Hash-based LRU cache with disk persistence
│   ├── llmlingua_core.py       # Unified compression engine
│   ├── image_optimizer.py      # Image optimization for vision APIs
│   ├── document_optimizer.py   # Document extraction & compression
│   ├── quality_reporter.py     # Multi-metric quality analysis
│   ├── metrics_tracker.py      # Persistent stats & cost tracking
│   ├── context_optimizer.py    # Graduated context compression
│   ├── output_compressor.py    # Output token compression
│   ├── welcome_wizard.py       # First-run setup wizard
│   ├── compress.py             # CLI: compress text
│   ├── compress_file.py        # CLI: compress files/docs/images
│   ├── compress_batch.py       # CLI: batch compress directories
│   └── test_quality.py         # CLI: quality test suite
├── service/                    # Daemon & integration
│   ├── daemon.py               # HTTP API server
│   ├── prompt_interceptor.py   # Agent Zero integration hooks
│   ├── file_watcher.py         # Auto-compress file watcher
│   └── control.sh              # Process management
├── examples/
│   └── sample.txt              # Sample text for testing
├── SKILL.md                    # This file
├── requirements.txt            # Python dependencies
├── Dockerfile                  # Docker container build
└── INSTALL_AND_START.sh        # One-command setup
```

## Model

- **Name**: `microsoft/llmlingua-2-xlm-roberta-large-meetingbank`
- **Size**: ~2GB download, cached locally after first load
- **Type**: XLM-RoBERTa Large fine-tuned for prompt compression
- **Cache**: `$TOKEN_OPT_CACHE_DIR/model_cache/`

## Requirements

- Python 3.9+
- ~2GB disk for model + ~4GB RAM
- Dependencies: llmlingua, transformers, torch, Pillow, sentencepiece

