import sys
import os
import time

base_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(base_dir, "scripts"))

from llmlingua_core import get_optimizer

texts = {
    "Long_Article": """
    Artificial intelligence (AI) is intelligence demonstrated by machines, as opposed to intelligence of humans and other animals. Example tasks in which this is done include speech recognition, computer vision, translation between (natural) languages, as well as other mappings of inputs.
    The AI applications include advanced web search engines (e.g., Google Search), recommendation systems (used by YouTube, Amazon, and Netflix), understanding human speech (such as Siri and Alexa), self-driving cars (e.g., Waymo), generative or creative tools (ChatGPT and AI art), automated decision-making, and competing at the highest level in strategic game systems (such as chess and Go).
    As machines become increasingly capable, tasks considered to require "intelligence" are often removed from the definition of AI, a phenomenon known as the AI effect. For instance, optical character recognition is frequently excluded from things considered to be AI, having become a routine technology.
    """,
    "Code_Snippet": """
    def calculate_fibonacci(n):
        if n <= 0:
            return 0
        elif n == 1:
            return 1
        else:
            a, b = 0, 1
            for _ in range(2, n + 1):
                a, b = b, a + b
            return b

    # Test the function
    for i in range(10):
        print(f"Fibonacci({i}) = {calculate_fibonacci(i)}")
    """
}

optimizer = get_optimizer()

print("\n=== Testing Compression Rate and Quality ===")
for name, text in texts.items():
    print(f"\n--- Testing {name} ---")
    start = time.time()
    res = optimizer.compress(text)
    orig_len = res.get('original_tokens', len(text.split()))
    comp_len = res.get('compressed_tokens', len(res.get('compressed', '').split()))
    ratio = res.get('ratio', 0)
    
    print(f"Original Length: {orig_len} tokens")
    print(f"Compressed Length: {comp_len} tokens")
    print(f"Compression Ratio: {ratio:.2f} ({(1-ratio)*100:.1f}% kept, {ratio*100:.1f}% saved)")
    print(f"Time taken: {time.time() - start:.4f}s")
    print(f"\nOriginal Snippet:\n{text[:150]}...")
    print(f"\nCompressed Snippet:\n{res.get('compressed')[:150]}...")
    print("-" * 40)
