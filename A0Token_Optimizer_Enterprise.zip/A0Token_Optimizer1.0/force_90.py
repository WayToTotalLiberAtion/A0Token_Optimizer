import re

file_path = '/a0/usr/projects/skill/A0Token_Optimizer/A0Token_Optimizer1.0/scripts/llmlingua_core.py'
with open(file_path, 'r') as f:
    content = f.read()

replacement = """        # Force exactly the target number of tokens based on the rate
        target_tokens_count = max(1, int(len(normalized.split()) * rate))
        
        result = self._model.compress_prompt(
                normalized.split("\\n"),
                instruction="",
                question="",
                target_token=target_tokens_count,
                force_tokens=[],
                chunk_end_tokens=[],
                return_word_label=False,
                keep_first_sentence=False,
                keep_last_sentence=False
            )"""

# Replace the compress_prompt call
pattern = r'result = self\._model\.compress_prompt\(.*?keep_last_sentence=False\s*\)'
new_content = re.sub(pattern, replacement, content, flags=re.DOTALL)

with open(file_path, 'w') as f:
    f.write(new_content)
