#!/bin/bash
# ============================================================================
# A0 Token Optimizer v5.0 - Installation & Setup
# ============================================================================
set -e

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
SCRIPTS="$BASE_DIR/scripts"
SERVICE="$BASE_DIR/service"
CACHE_DIR="${TOKEN_OPT_CACHE_DIR:-/var/cache/a0-token-optimizer}"
CONFIG_FILE="$CACHE_DIR/user_config.json"

echo "============================================================================"
echo " A0 Token Optimizer v5.0 - Installation"
echo "============================================================================"
echo

# 1. Create directories
echo "[1/5] Creating directories..."
mkdir -p "$CACHE_DIR"/{metrics,model_cache,compression_cache,watch,output}
echo "  Cache: $CACHE_DIR"

# 2. Install Python dependencies
echo
echo "[2/5] Installing Python dependencies..."
if command -v pip3 &>/dev/null; then
    pip3 install -r "$BASE_DIR/requirements.txt" 2>&1 | tail -5
elif command -v pip &>/dev/null; then
    pip install -r "$BASE_DIR/requirements.txt" 2>&1 | tail -5
else
    echo "  WARNING: pip not found. Install dependencies manually:"
    echo "  pip install -r $BASE_DIR/requirements.txt"
fi

# 3. Make scripts executable
echo
echo "[3/5] Setting permissions..."
chmod +x "$SERVICE/control.sh" 2>/dev/null || true
chmod +x "$SCRIPTS"/*.py 2>/dev/null || true
chmod +x "$SERVICE"/*.py 2>/dev/null || true

# 4. Run welcome wizard (shows info, configures image optimization)
echo
echo "[4/5] Running setup wizard..."
echo
cd "$BASE_DIR" && python3 "$SCRIPTS/welcome_wizard.py" "$@"

# 5. Start daemon
echo
echo "[5/5] Starting daemon..."
cd "$BASE_DIR" && bash "$SERVICE/control.sh" start

echo
echo "============================================================================"
echo " Installation complete! A0 Token Optimizer v5.0 is running."
echo "============================================================================"
