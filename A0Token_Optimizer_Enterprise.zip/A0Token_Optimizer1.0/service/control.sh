#!/bin/bash
# A0 Token Optimizer v5.0 - Process Control
# Usage: control.sh {start|stop|restart|status|logs}

BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SCRIPTS="$BASE_DIR/scripts"
SERVICE="$BASE_DIR/service"
CACHE_DIR="${TOKEN_OPT_CACHE_DIR:-/var/cache/a0-token-optimizer}"
PID_FILE="$CACHE_DIR/daemon.pid"
LOG_FILE="$CACHE_DIR/daemon.log"
PORT="${TOKEN_OPT_PORT:-9199}"
HOST="${TOKEN_OPT_HOST:-127.0.0.1}"

mkdir -p "$CACHE_DIR"

case "$1" in
    start)
        if [ "$2" == "--foreground" ]; then
            echo "[A0-TokenOpt] Starting daemon in FOREGROUND (Docker mode)..."
            cd "$SERVICE" && exec python3 daemon.py --preload
        fi
        if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
            echo "[A0-TokenOpt] Daemon already running (PID: $(cat "$PID_FILE"))"
            exit 0
        fi
        echo "[A0-TokenOpt] Starting daemon on $HOST:$PORT..."
        cd "$SERVICE" && nohup python3 daemon.py --preload > "$LOG_FILE" 2>&1 &
        echo $! > "$PID_FILE"
        sleep 2
        if kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
            echo "[A0-TokenOpt] Daemon started (PID: $(cat "$PID_FILE"))"
            echo "[A0-TokenOpt] Dashboard: http://$HOST:$PORT/dashboard"
        else
            echo "[A0-TokenOpt] ERROR: Daemon failed to start. Check $LOG_FILE"
            exit 1
        fi
        ;;
    stop)
        if [ -f "$PID_FILE" ]; then
            PID=$(cat "$PID_FILE")
            if kill -0 "$PID" 2>/dev/null; then
                echo "[A0-TokenOpt] Stopping daemon (PID: $PID)..."
                kill "$PID"
                sleep 2
                if kill -0 "$PID" 2>/dev/null; then
                    kill -9 "$PID"
                fi
                echo "[A0-TokenOpt] Daemon stopped."
            else
                echo "[A0-TokenOpt] Daemon not running (stale PID file)."
            fi
            rm -f "$PID_FILE"
        else
            echo "[A0-TokenOpt] No PID file found. Daemon not running."
        fi
        ;;
    restart)
        if [ "$2" == "--foreground" ]; then
            echo "[A0-TokenOpt] Starting daemon in FOREGROUND (Docker mode)..."
            cd "$SERVICE" && exec python3 daemon.py --preload
        fi
        $0 stop
        sleep 1
        $0 start
        ;;
    status)
        if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
            echo "[A0-TokenOpt] Daemon RUNNING (PID: $(cat "$PID_FILE"))"
            # Health check
            HEALTH=$(curl -s "http://$HOST:$PORT/health" 2>/dev/null)
            if [ -n "$HEALTH" ]; then
                echo "[A0-TokenOpt] Health: $HEALTH"
            fi
        else
            echo "[A0-TokenOpt] Daemon NOT RUNNING"
        fi
        ;;
    logs)
        if [ -f "$LOG_FILE" ]; then
            tail -f "$LOG_FILE"
        else
            echo "[A0-TokenOpt] No log file found."
        fi
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|logs}"
        exit 1
        ;;
esac
