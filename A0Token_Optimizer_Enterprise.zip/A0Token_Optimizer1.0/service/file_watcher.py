#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - File Watcher
Monitors a directory for new text files and images, automatically compresses them.
Uses threading.Timer (no SIGALRM) for Docker compatibility.
"""
from image_optimizer import get_image_optimizer
import config
import os
import sys
import time
import threading
import hashlib
from pathlib import Path

scripts_dir = os.path.join(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__))),
    "scripts")
sys.path.insert(0, scripts_dir)


class FileWatcher:
    """Watch directory for new files and auto-compress."""

    TEXT_EXTENSIONS = {
        ".txt",
        ".md",
        ".log",
        ".json",
        ".xml",
        ".html",
        ".csv",
        ".yaml",
        ".yml",
        ".rst"}
    IMAGE_EXTENSIONS = {
        ".jpg",
        ".jpeg",
        ".png",
        ".webp",
        ".bmp",
        ".tiff",
        ".gif"}
    DOC_EXTENSIONS = {".pdf", ".docx", ".rtf"}

    def __init__(self, watch_dir=None, output_dir=None, interval=None):
        self.watch_dir = watch_dir or config.WATCH_DIR
        self.output_dir = output_dir or config.OUTPUT_DIR
        self.interval = interval or config.WATCH_INTERVAL
        self._processed = {}  # hash -> timestamp
        self._running = False
        self._timer = None
        self._lock = threading.Lock()
        self._max_processed = 5000

    def start(self):
        """Start watching."""
        os.makedirs(self.watch_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)
        self._running = True
        print(f"[FileWatcher] Watching: {self.watch_dir}")
        print(f"[FileWatcher] Output: {self.output_dir}")
        print(f"[FileWatcher] Interval: {self.interval}s")
        self._schedule_next()

    def stop(self):
        """Stop watching."""
        self._running = False
        if self._timer:
            self._timer.cancel()
        print("[FileWatcher] Stopped.")

    def _schedule_next(self):
        if not self._running:
            return
        self._timer = threading.Timer(self.interval, self._scan)
        self._timer.daemon = True
        self._timer.start()

    def _file_hash(self, path: str) -> str:
        """Hash file path + mtime for change detection."""
        stat = os.stat(path)
        content = f"{path}:{stat.st_size}:{stat.st_mtime}"
        return hashlib.md5(content.encode()).hexdigest()

    def _scan(self):
        """Scan directory for new/changed files."""
        try:
            watch_path = Path(self.watch_dir)
            for file_path in watch_path.iterdir():
                if not file_path.is_file():
                    continue

                fhash = self._file_hash(str(file_path))
                if fhash in self._processed:
                    continue

                ext = file_path.suffix.lower()
                try:
                    if ext in self.TEXT_EXTENSIONS:
                        self._process_text(file_path)
                    elif ext in self.IMAGE_EXTENSIONS:
                        self._process_image(file_path)
                    elif ext in self.DOC_EXTENSIONS:
                        self._process_document(file_path)
                    else:
                        continue

                    self._processed[fhash] = time.time()
                except Exception as e:
                    print(
                        f"[FileWatcher] Error processing {
                            file_path.name}: {e}")
                    # Mark to avoid retry loop
                    self._processed[fhash] = time.time()

            # Evict old entries
            if len(self._processed) > self._max_processed:
                sorted_items = sorted(
                    self._processed.items(), key=lambda x: x[1])
                self._processed = dict(sorted_items[len(sorted_items) // 2:])

        except Exception as e:
            print(f"[FileWatcher] Scan error: {e}")
        finally:
            self._schedule_next()

    def _process_text(self, file_path: Path):
        """Compress text file."""
        from llmlingua_core import get_optimizer
        from metrics_tracker import get_metrics

        text = file_path.read_text(encoding="utf-8", errors="replace")
        if len(text.strip()) < 50:
            return

        optimizer = get_optimizer()
        result = optimizer.compress(text, profile="auto", direction="input")
        get_metrics().record_compression(result)

        out_name = file_path.stem + "_compressed" + file_path.suffix
        out_path = Path(self.output_dir) / out_name
        out_path.write_text(result["compressed_text"], encoding="utf-8")

        pct = result.get("char_reduction_pct", 0)
        print(
            f"[FileWatcher] Compressed: {
                file_path.name} → {out_name} ({pct}% reduction)")

    def _process_image(self, file_path: Path):
        """Optimize image file."""
        from metrics_tracker import get_metrics

        img_opt = get_image_optimizer()
        if not img_opt.is_enabled():
            return

        out_path = Path(self.output_dir) / (file_path.stem +
                                            "_optimized" + file_path.suffix)
        result = img_opt.optimize(str(file_path), str(out_path))

        if "error" not in result and not result.get("skipped"):
            get_metrics().record_image_optimization(result)
            pct = result.get("size_reduction_pct", 0)
            tsaved = result.get("tokens_saved", 0)
            print(
                f"[FileWatcher] Image optimized: {
                    file_path.name} ({pct}% size, {tsaved} tokens saved)")

    def _process_document(self, file_path: Path):
        """Compress document file."""
        from document_optimizer import get_document_optimizer
        from metrics_tracker import get_metrics

        doc_opt = get_document_optimizer()
        if not doc_opt.is_enabled():
            return

        out_path = str(Path(self.output_dir) /
                       (file_path.stem + "_compressed.txt"))
        result = doc_opt.optimize(str(file_path), output_path=out_path)

        if "error" not in result and not result.get("skipped"):
            get_metrics().record_compression(result)
            get_metrics().record_document_compression()
            print(f"[FileWatcher] Document compressed: {file_path.name}")


def run_watcher(watch_dir=None, output_dir=None):
    """Start file watcher (blocking)."""
    watcher = FileWatcher(watch_dir=watch_dir, output_dir=output_dir)
    watcher.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        watcher.stop()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
        description="A0 Token Optimizer File Watcher")
    parser.add_argument("--watch-dir", default=None)
    parser.add_argument("--output-dir", default=None)
    args = parser.parse_args()
    run_watcher(watch_dir=args.watch_dir, output_dir=args.output_dir)
