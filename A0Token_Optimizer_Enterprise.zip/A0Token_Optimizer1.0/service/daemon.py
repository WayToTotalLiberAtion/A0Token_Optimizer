#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - FastAPI Daemon
Serves compression API with endpoints using high-performance async FastAPI.
Security features: 20MB body limit, CORS restriction, Path Traversal protection.
"""
import os
import sys
# Add the root and scripts directories to sys.path
root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_dir)
sys.path.insert(0, os.path.join(root_dir, "scripts"))

from quality_reporter import QualityReporter
from output_compressor import get_output_compressor
from context_optimizer import get_context_optimizer
from document_optimizer import get_document_optimizer
from image_optimizer import get_image_optimizer
from metrics_tracker import get_metrics
from llmlingua_core import get_optimizer
import config
import signal
import uvicorn
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware

from starlette.middleware.base import BaseHTTPMiddleware

# Add scripts to path
scripts_dir = os.path.join(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__))),
    "scripts")
sys.path.insert(0, scripts_dir)


app = FastAPI(title="A0 Token Optimizer", version="5.0.0")

# Security: CORS restriction (only localhost/127.0.0.1)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1",
        "http://localhost",
        "https://127.0.0.1",
        "https://localhost"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)

# Security: Max Body Size 20MB
MAX_BODY_SIZE = 20 * 1024 * 1024


class MaxBodySizeMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if "content-length" in request.headers:
            if int(request.headers["content-length"]) > MAX_BODY_SIZE:
                return JSONResponse(status_code=413, content={
                                    "error": "Payload Too Large: Maximum 20MB allowed"})
        return await call_next(request)


app.add_middleware(MaxBodySizeMiddleware)


def is_safe_path(path: str) -> bool:
    """Security: Prevent Path Traversal and access to sensitive system files."""
    if not path:
        return False
    abs_path = os.path.abspath(path)
    if ".." in path:
        return False
    sensitive_prefixes = ("/etc", "/root", "/var/lib", "/proc", "/sys", "/dev")
    if abs_path.startswith(sensitive_prefixes):
        return False
    return True


@app.get("/health")
async def health():
    opt = get_optimizer()
    return {"status": "healthy", "model_loaded": opt.is_loaded(),
            "version": "5.0.0"}


@app.get("/stats")
async def stats():
    opt = get_optimizer()
    return {"engine": opt.get_stats(), "metrics": get_metrics().get_dashboard()}


@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard():
    return get_metrics().get_dashboard_html()


@app.get("/config")
async def get_config():
    return config.get_effective_config()


@app.post("/compress")
async def compress(request: Request):
    try:
        data = await request.json()
    except BaseException:
        data = {}
    text = data.get("text", data.get("raw", ""))
    if not text:
        raise HTTPException(status_code=400, detail="No text provided")

    opt = get_optimizer()
    result = opt.compress(
        text,
        rate=data.get("rate"),
        profile=data.get("profile", "auto"),
        direction=data.get("direction", "input"),
    )

    if config.get_effective_config().get("quality_reports", True):
        result["quality"] = QualityReporter().analyze(
            text, result.get("compressed_text", text))

    get_metrics().record_compression(result)
    return result


@app.post("/compress/output")
async def compress_output(request: Request):
    try:
        data = await request.json()
    except BaseException:
        data = {}
    text = data.get("text", "")
    if not text:
        raise HTTPException(status_code=400, detail="No text provided")

    comp = get_output_compressor()
    result = comp.compress_response(text, rate=data.get("rate"))
    if not result.get("skipped"):
        get_metrics().record_compression(result)
    return result


@app.post("/compress/document")
async def compress_document(request: Request):
    data = await request.json()
    file_path = data.get("file_path", "")
    if not file_path:
        raise HTTPException(status_code=400, detail="No file_path provided")
    if not is_safe_path(file_path):
        raise HTTPException(status_code=403, detail="Forbidden file path")

    doc_opt = get_document_optimizer()
    try:
        return doc_opt.optimize(file_path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/compress/image")
async def compress_image(request: Request):
    data = await request.json()
    file_path = data.get("file_path", "")
    if not file_path:
        raise HTTPException(status_code=400, detail="No file_path provided")
    if not is_safe_path(file_path):
        raise HTTPException(status_code=403, detail="Forbidden file path")

    img_opt = get_image_optimizer()
    try:
        return img_opt.optimize(file_path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/compress/context")
async def compress_context(request: Request):
    data = await request.json()
    messages = data.get("messages", [])
    if not messages:
        raise HTTPException(status_code=400, detail="No messages provided")

    ctx_opt = get_context_optimizer()
    try:
        return ctx_opt.optimize_messages(
            messages, system_prompt=data.get("system_prompt"))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/config")
async def update_config(request: Request):
    data = await request.json()
    return config.save_user_config(data)


@app.post("/shutdown")
async def shutdown():
    os.kill(os.getpid(), signal.SIGINT)
    return {"status": "shutting_down"}

if __name__ == "__main__":
    uvicorn.run(
        "daemon:app",
        host=config.DAEMON_HOST,
        port=config.DAEMON_PORT,
        workers=1)
