import sys
import os
import json
import math
from collections import Counter

# Ensure scripts module can be imported
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from scripts.llmlingua_core import get_optimizer
from scripts.quality_reporter import QualityReporter

sample_text = """
Artificial intelligence (AI) is intelligence demonstrated by machines, as opposed to intelligence of humans and other animals. 
Example tasks in which this is done include speech recognition, computer vision, translation between (natural) languages, as well as other mappings of inputs. 
The Oxford English Dictionary of Oxford University Press defines artificial intelligence as:
"the theory and development of computer systems able to perform tasks that normally require human intelligence, such as visual perception, speech recognition, decision-making, and translation between languages."
AI applications include advanced web search engines (e.g., Google Search), recommendation systems (used by YouTube, Amazon, and Netflix), understanding human speech (such as Siri and Alexa), self-driving cars (e.g., Waymo), generative or creative tools (ChatGPT and AI art), automated decision-making, and competing at the highest level in strategic game systems (such as chess and Go).
"""

print('--- Testing Standard Fixed Compression (Rate = 0.1 / 90%) ---')
opt = get_optimizer()
try:
    result1 = opt.compress(sample_text)
    reporter = QualityReporter()
    quality1 = reporter.analyze(sample_text, result1.get('compressed_text', ''))
    
    output1 = {
        'original_tokens': result1.get('original_tokens'),
        'compressed_tokens': result1.get('compressed_tokens'),
        'compression_ratio': result1.get('compression_ratio'),
        'quality_score': quality1.get('quality_score'),
        'compressed_text_sample': result1.get('compressed_text')[:150] + '...'
    }
    print(json.dumps(output1, indent=2))
except Exception as e:
    print(f'Error during standard test: {e}')

print('\n--- Simulating Dynamic Entropy Compression ---')
def calculate_entropy(text):
    words = text.split()
    word_counts = Counter(words)
    total_words = len(words)
    if total_words == 0: return 0
    return -sum((count/total_words) * math.log2(count/total_words) for count in word_counts.values())

entropy = calculate_entropy(sample_text)
dynamic_rate = round(min(0.3, max(0.05, 0.1 * (entropy / 5.0))), 3)
print(f'Calculated Text Entropy: {entropy:.2f}')
print(f'Dynamically adjusted rate based on entropy: {dynamic_rate}')

try:
    result2 = opt.compress(sample_text, rate=dynamic_rate)
    quality2 = reporter.analyze(sample_text, result2.get('compressed_text', ''))
    
    output2 = {
        'original_tokens': result2.get('original_tokens'),
        'compressed_tokens': result2.get('compressed_tokens'),
        'compression_ratio': result2.get('compression_ratio'),
        'quality_score': quality2.get('quality_score'),
        'compressed_text_sample': result2.get('compressed_text')[:150] + '...'
    }
    print(json.dumps(output2, indent=2))
except Exception as e:
    print(f'Error during entropy test: {e}')
