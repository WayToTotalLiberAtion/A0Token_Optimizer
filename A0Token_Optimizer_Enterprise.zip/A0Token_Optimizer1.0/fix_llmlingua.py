with open('/a0/usr/projects/skill/A0Token_Optimizer/A0Token_Optimizer1.0/scripts/llmlingua_core.py', 'r') as f:
    lines = f.readlines()

with open('/a0/usr/projects/skill/A0Token_Optimizer/A0Token_Optimizer1.0/scripts/llmlingua_core.py', 'w') as f:
    skip = False
    for line in lines:
        if 'target_tokens_count = max(1' in line:
            skip = True
        if skip and ')' in line and 'keep_last_sentence=False' in line:
            skip = False
            continue
        if skip:
            continue
            
        # Find the try block
        if 'try:' in line and 'start_time = time.time()' not in line:
            # Write our custom block
            f.write('        target_tokens_count = max(1, int(len(normalized.split()) * rate))\n')
            f.write('        try:\n')
            f.write('            result = self._model.compress_prompt(\n')
            f.write('                normalized.split("\\n"),\n')
            f.write('                instruction="",\n')
            f.write('                question="",\n')
            f.write('                target_token=target_tokens_count,\n')
            f.write('                force_tokens=[],\n')
            f.write('                chunk_end_tokens=[],\n')
            f.write('                return_word_label=False,\n')
            f.write('                keep_first_sentence=False,\n')
            f.write('                keep_last_sentence=False\n')
            f.write('            )\n')
            skip = True # skip the old try block content
        elif 'compressed_text = result.get' in line:
            skip = False
            f.write(line)
        else:
            if not skip:
                f.write(line)
