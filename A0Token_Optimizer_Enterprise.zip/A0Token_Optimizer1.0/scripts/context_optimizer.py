#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Context Window Optimizer (B3)
Graduated compression for chat histories:
- Recent messages: no compression
- Mid-age messages: light compression
- Old messages: heavy compression
- System prompt: configurable

This is the KILLER FEATURE for Agent Zero - maximizes context window utilization.
"""
import config
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


class ContextWindowOptimizer:
    """Graduated compression for conversation contexts."""

    def __init__(self):
        self._compressor = None

    def _get_compressor(self):
        if self._compressor is None:
            from llmlingua_core import get_optimizer
            self._compressor = get_optimizer()
        return self._compressor

    def is_enabled(self) -> bool:
        cfg = config.get_effective_config()
        return cfg.get("context_optimizer", config.CONTEXT_OPT_ENABLED)

    def optimize_messages(self, messages: list, system_prompt: str = None,
                          compress_system: bool = False) -> dict:
        """Optimize a list of conversation messages with graduated compression.

        Args:
            messages: List of dicts with 'role' and 'content' keys
            system_prompt: System prompt text (compressed conservatively or skipped)
            compress_system: Whether to compress system prompt

        Returns:
            dict with optimized messages and stats
        """
        if not self.is_enabled():
            return {"messages": messages,
                    "system_prompt": system_prompt, "skipped": True}

        config.get_effective_config()
        recent_keep = config.CONTEXT_RECENT_KEEP
        mid_rate = config.CONTEXT_MID_RATE
        old_rate = config.CONTEXT_OLD_RATE

        total_messages = len(messages)
        optimized = []
        stats = {
            "total_messages": total_messages,
            "uncompressed": 0,
            "light_compressed": 0,
            "heavy_compressed": 0,
            "original_chars": 0,
            "compressed_chars": 0,
        }

        compressor = self._get_compressor()

        # Process system prompt
        opt_system = system_prompt
        if system_prompt and compress_system:
            result = compressor.compress(
                system_prompt,
                rate=0.35,
                profile="system_prompt",
                direction="input")
            opt_system = result["compressed_text"]
            stats["system_prompt_compressed"] = True
            stats["system_chars_before"] = len(system_prompt)
            stats["system_chars_after"] = len(opt_system)
        else:
            stats["system_prompt_compressed"] = False

        # Process messages with graduated compression
        for i, msg in enumerate(messages):
            # Distance from most recent (1 = most recent)
            age = total_messages - i
            content = msg.get("content", "")
            role = msg.get("role", "user")
            stats["original_chars"] += len(content)

            if age <= recent_keep:
                # Recent: no compression
                optimized.append({"role": role, "content": content})
                stats["uncompressed"] += 1
                stats["compressed_chars"] += len(content)

            elif age <= recent_keep + 7:
                # Mid-range: light compression
                if len(content) > 100:  # Don't compress tiny messages
                    result = compressor.compress(
                        content, rate=mid_rate, profile="chat_history", direction="input")
                    compressed = result["compressed_text"]
                else:
                    compressed = content
                optimized.append({"role": role, "content": compressed})
                stats["light_compressed"] += 1
                stats["compressed_chars"] += len(compressed)

            else:
                # Old: heavy compression
                if len(content) > 50:
                    result = compressor.compress(
                        content, rate=old_rate, profile="chat_history", direction="input")
                    compressed = result["compressed_text"]
                else:
                    compressed = content
                optimized.append({"role": role, "content": compressed})
                stats["heavy_compressed"] += 1
                stats["compressed_chars"] += len(compressed)

        stats["total_reduction_pct"] = round(
            (1 - stats["compressed_chars"] /
             max(stats["original_chars"], 1)) * 100, 2
        )

        return {
            "messages": optimized,
            "system_prompt": opt_system,
            "stats": stats,
        }

    def optimize_context_string(self, context: str,
                                recent_chars: int = 2000) -> dict:
        """Optimize a single context string.
        Keep last `recent_chars` uncompressed, compress the rest.
        """
        if not self.is_enabled():
            return {"text": context, "skipped": True}

        if len(context) <= recent_chars:
            return {"text": context, "skipped": True,
                    "reason": "Context small enough"}

        old_part = context[:-recent_chars]
        recent_part = context[-recent_chars:]

        compressor = self._get_compressor()
        result = compressor.compress(
            old_part,
            rate=config.CONTEXT_OLD_RATE,
            profile="chat_history",
            direction="input")

        merged = result["compressed_text"] + "\n" + recent_part
        return {
            "text": merged,
            "original_chars": len(context),
            "optimized_chars": len(merged),
            "reduction_pct": round((1 - len(merged) / len(context)) * 100, 2),
        }


# Singleton
_ctx_opt = None


def get_context_optimizer() -> ContextWindowOptimizer:
    global _ctx_opt
    if _ctx_opt is None:
        _ctx_opt = ContextWindowOptimizer()
    return _ctx_opt


def optimize_messages(messages: list, system_prompt: str = None) -> dict:
    return get_context_optimizer().optimize_messages(messages, system_prompt)
