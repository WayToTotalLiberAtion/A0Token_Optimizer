#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Content-Type Profiler (A3)
Auto-detects content type and selects optimal compression profile.
"""
import re
import json as _json
from config import PROFILES


class ContentProfiler:
    """Detect content type from text analysis."""

    # Detection patterns with weights
    INDICATORS = {
        "code": [
            (r"^(import |from .+ import |#include |using |package )", 3),
            (r"(def |class |function |const |let |var |public |private )", 3),
            (r"[{};]\s*$", 2),
            (r"(if\s*\(|for\s*\(|while\s*\(|switch\s*\()", 2),
            (r"(=>|->|\|\||&&|!=|==)", 1),
            (r"^\s{2,}(return|break|continue|yield)", 2),
        ],
        "json": [
            (r'^\s*[{\[]', 5),
            (r'"[^"]+"\s*:', 4),
            (r'^\s*[}\]]\s*,?\s*$', 3),
        ],
        "markdown": [
            (r"^#{1,6}\s", 3),
            (r"^\s*[-*+]\s", 2),
            (r"\[.+\]\(.+\)", 3),
            (r"```", 4),
            (r"\*\*.+\*\*", 2),
        ],
        "chat_history": [
            (r"^(User|Assistant|Human|AI|System)\s*:", 5),
            (r"^\[?\d{1,2}[:/]\d{2}", 3),
            (r"^(> |>> )", 2),
            (r"^(Q:|A:|>>>)", 3),
        ],
        "system_prompt": [
            (r"(?i)(you are|your role|you must|always|never|instructions)", 3),
            (r"(?i)(respond|format|output|rules|guidelines)", 2),
            (r"(?i)(do not|don't|prohibited|forbidden|required)", 2),
        ],
        "documentation": [
            (r"(?i)^(chapter|section|appendix|table of contents)", 4),
            (r"(?i)(see also|refer to|for more|example:)", 2),
            (r"(?i)(installation|usage|configuration|api reference)", 3),
            (r"\d+\.\d+(\.\d+)?\s", 1),  # version numbers
        ],
    }

    @classmethod
    def detect(cls, text: str) -> dict:
        """Detect content type. Returns profile name and confidence scores."""
        if not text or not text.strip():
            return {"profile": "prose", "confidence": 0.0, "scores": {}}

        # Quick JSON check
        stripped = text.strip()
        if stripped.startswith(("{", "[")):
            try:
                _json.loads(stripped)
                return {"profile": "json", "confidence": 1.0,
                        "scores": {"json": 100}}
            except (ValueError, TypeError):
                pass

        # Score each profile
        scores = {}
        lines = text.split("\n")[:100]  # Sample first 100 lines
        sample = "\n".join(lines)

        for profile, patterns in cls.INDICATORS.items():
            score = 0
            for pattern, weight in patterns:
                matches = len(re.findall(pattern, sample, re.MULTILINE))
                score += matches * weight
            scores[profile] = score

        # Determine winner
        if not scores or max(scores.values()) == 0:
            return {"profile": "prose", "confidence": 0.5, "scores": scores}

        best = max(scores, key=scores.get)
        total = sum(scores.values()) or 1
        confidence = round(scores[best] / total, 3)

        # Low confidence → default to prose
        if confidence < 0.3:
            return {"profile": "prose",
                    "confidence": confidence, "scores": scores}

        return {"profile": best, "confidence": confidence, "scores": scores}

    @classmethod
    def get_profile(cls, text: str, override: str = None) -> dict:
        """Get compression profile for text. Override to force specific profile."""
        if override and override != "auto" and override in PROFILES:
            profile_name = override
            detection = {
                "profile": override,
                "confidence": 1.0,
                "scores": {},
                "overridden": True}
        else:
            detection = cls.detect(text)
            profile_name = detection["profile"]

        profile_config = PROFILES.get(profile_name, PROFILES["prose"]).copy()
        profile_config["name"] = profile_name
        return {"detection": detection, "config": profile_config}


def detect_content_type(text: str) -> str:
    """Convenience: returns just the profile name."""
    return ContentProfiler.detect(text)["profile"]


def get_compression_profile(text: str, override: str = None) -> dict:
    """Convenience: returns full profile with config."""
    return ContentProfiler.get_profile(text, override)


if __name__ == "__main__":
    samples = {
        "code": "import os\ndef main():\n    x = 10\n    if x > 5:\n        return True",
        "json": '{"name": "test", "value": 42, "nested": {"key": "val"}}',
        "chat": "User: Hello\nAssistant: Hi there!\nUser: How are you?",
        "prose": "The quick brown fox jumps over the lazy dog. This is a sample text.",
    }
    for label, text in samples.items():
        result = ContentProfiler.detect(text)
        print(
            f"{label:>10} => detected: {result['profile']} (conf: {result['confidence']})")
