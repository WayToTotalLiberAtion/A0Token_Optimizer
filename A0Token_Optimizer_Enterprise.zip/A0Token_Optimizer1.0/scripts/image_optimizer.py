#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Image Optimizer
Reduces image token cost by resizing, recompressing, and format-converting
images before they are sent to vision-capable LLMs.

Default: ON (configurable via welcome wizard or config).
Supports: JPEG, PNG, WebP, BMP, TIFF, GIF

Token cost estimation based on OpenAI/Anthropic tile-based pricing:
  - Images are split into 512x512 tiles
  - Each tile costs ~170 tokens (GPT-4V) or ~1600 tokens (Claude)
  - Smaller image = fewer tiles = fewer tokens
"""
import config
import os
import sys
import math
import io
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


class ImageOptimizer:
    """Optimize images to reduce LLM vision token cost."""

    TILE_SIZE = 512  # pixels per tile
    TOKENS_PER_TILE_GPT4V = 170
    TOKENS_PER_TILE_CLAUDE = 1600
    BASE_TOKENS_GPT4V = 85
    BASE_TOKENS_CLAUDE = 1600

    SUPPORTED_FORMATS = {
        ".jpg",
        ".jpeg",
        ".png",
        ".webp",
        ".bmp",
        ".tiff",
        ".tif",
        ".gif"}

    def __init__(self):
        self._pil_available = None

    def _ensure_pil(self):
        """Check if Pillow is available."""
        if self._pil_available is None:
            try:
                self._pil_available = True
            except ImportError:
                self._pil_available = False
        return self._pil_available

    def is_enabled(self) -> bool:
        """Check if image optimization is enabled."""
        cfg = config.get_effective_config()
        return cfg.get("image_optimization", config.IMAGE_OPT_ENABLED)

    def estimate_tokens(self, width: int, height: int,
                        model: str = "gpt4v") -> int:
        """Estimate token cost of an image by dimensions."""
        tiles_w = math.ceil(width / self.TILE_SIZE)
        tiles_h = math.ceil(height / self.TILE_SIZE)
        total_tiles = tiles_w * tiles_h
        if model == "claude":
            return self.BASE_TOKENS_CLAUDE + \
                (total_tiles * self.TOKENS_PER_TILE_CLAUDE)
        return self.BASE_TOKENS_GPT4V + \
            (total_tiles * self.TOKENS_PER_TILE_GPT4V)

    def optimize(self, input_path: str, output_path: str = None,
                 max_width: int = None, max_height: int = None,
                 quality: int = None, output_format: str = None) -> dict:
        """Optimize a single image file.

        Args:
            input_path: Path to source image
            output_path: Path to save optimized image (default: overwrite)
            max_width: Maximum width in pixels
            max_height: Maximum height in pixels
            quality: JPEG/WebP quality (1-100)
            output_format: Target format (JPEG, PNG, WEBP)

        Returns:
            dict with optimization stats
        """
        if not self.is_enabled():
            return {"skipped": True, "reason": "Image optimization disabled"}

        if not self._ensure_pil():
            return {"error": "Pillow not installed. Run: pip install Pillow"}

        from PIL import Image

        cfg = config.get_effective_config()
        max_width = max_width or cfg.get(
            "image_max_width", config.IMAGE_MAX_WIDTH)
        max_height = max_height or cfg.get(
            "image_max_height", config.IMAGE_MAX_HEIGHT)
        quality = quality or cfg.get("image_quality", config.IMAGE_QUALITY)
        output_format = output_format or config.IMAGE_FORMAT

        input_path = str(input_path)
        if not os.path.exists(input_path):
            return {"error": f"File not found: {input_path}"}

        ext = os.path.splitext(input_path)[1].lower()
        if ext not in self.SUPPORTED_FORMATS:
            return {"error": f"Unsupported format: {ext}"}

        original_size = os.path.getsize(input_path)

        try:
            img = Image.open(input_path)
            original_w, original_h = img.size
            img.mode

            tokens_before = self.estimate_tokens(original_w, original_h)

            # Resize if exceeds limits
            resized = False
            new_w, new_h = original_w, original_h
            if original_w > max_width or original_h > max_height:
                ratio = min(max_width / original_w, max_height / original_h)
                new_w = int(original_w * ratio)
                new_h = int(original_h * ratio)
                img = img.resize((new_w, new_h), Image.LANCZOS)
                resized = True

            # Convert mode for JPEG
            if output_format.upper() == "JPEG" and img.mode in ("RGBA", "P", "LA"):
                bg = Image.new("RGB", img.size, (255, 255, 255))
                if img.mode == "P":
                    img = img.convert("RGBA")
                bg.paste(img, mask=img.split()[-1]
                         if "A" in img.mode else None)
                img = bg
            elif output_format.upper() == "JPEG" and img.mode != "RGB":
                img = img.convert("RGB")

            # Save to buffer to measure size
            buffer = io.BytesIO()
            save_kwargs = {}
            if output_format.upper() in ("JPEG", "WEBP"):
                save_kwargs["quality"] = quality
                save_kwargs["optimize"] = True
            if output_format.upper() == "PNG":
                save_kwargs["optimize"] = True

            img.save(buffer, format=output_format.upper(), **save_kwargs)
            optimized_size = buffer.tell()

            tokens_after = self.estimate_tokens(new_w, new_h)

            # Only save if actually smaller
            if optimized_size < original_size:
                out = output_path or input_path
                # Adjust extension
                fmt_ext = {"JPEG": ".jpg", "PNG": ".png", "WEBP": ".webp"}
                if output_path is None:
                    base = os.path.splitext(input_path)[0]
                    out = base + fmt_ext.get(output_format.upper(), ext)
                with open(out, "wb") as f:
                    buffer.seek(0)
                    f.write(buffer.read())
                saved = True
            else:
                out = input_path
                optimized_size = original_size
                saved = False

            return {
                "input_path": input_path,
                "output_path": out,
                "original_size_bytes": original_size,
                "optimized_size_bytes": optimized_size,
                "size_reduction_pct": round((1 - optimized_size / max(original_size, 1)) * 100, 2),
                "original_dimensions": f"{original_w}x{original_h}",
                "optimized_dimensions": f"{new_w}x{new_h}",
                "resized": resized,
                "tokens_before": tokens_before,
                "tokens_after": tokens_after,
                "tokens_saved": tokens_before - tokens_after,
                "token_reduction_pct": round((1 - tokens_after / max(tokens_before, 1)) * 100, 2),
                "format": output_format.upper(),
                "quality": quality,
                "file_saved": saved,
            }

        except Exception as e:
            return {"error": str(e), "input_path": input_path}

    def optimize_directory(self, dir_path: str, output_dir: str = None,
                           recursive: bool = True) -> dict:
        """Optimize all images in a directory."""
        if not self.is_enabled():
            return {"skipped": True, "reason": "Image optimization disabled"}

        results = []
        total_saved = 0
        total_tokens_saved = 0

        dir_path = Path(dir_path)
        if not dir_path.exists():
            return {"error": f"Directory not found: {dir_path}"}

        pattern = "**/*" if recursive else "*"
        for file_path in sorted(dir_path.glob(pattern)):
            if file_path.suffix.lower() in self.SUPPORTED_FORMATS:
                if output_dir:
                    rel = file_path.relative_to(dir_path)
                    out = Path(output_dir) / rel
                    out.parent.mkdir(parents=True, exist_ok=True)
                    out = str(out)
                else:
                    out = None
                result = self.optimize(str(file_path), out)
                results.append(result)
                if "size_reduction_pct" in result:
                    total_saved += result["original_size_bytes"] - \
                        result["optimized_size_bytes"]
                    total_tokens_saved += result.get("tokens_saved", 0)

        return {
            "files_processed": len(results),
            "total_bytes_saved": total_saved,
            "total_tokens_saved": total_tokens_saved,
            "results": results,
        }

    def optimize_bytes(self, image_data: bytes, filename: str = "image.jpg",
                       max_width: int = None, max_height: int = None,
                       quality: int = None) -> dict:
        """Optimize image from bytes (for API/interceptor use)."""
        if not self.is_enabled():
            return {"skipped": True, "data": image_data}

        if not self._ensure_pil():
            return {"error": "Pillow not installed", "data": image_data}

        from PIL import Image

        cfg = config.get_effective_config()
        max_width = max_width or cfg.get(
            "image_max_width", config.IMAGE_MAX_WIDTH)
        max_height = max_height or cfg.get(
            "image_max_height", config.IMAGE_MAX_HEIGHT)
        quality = quality or cfg.get("image_quality", config.IMAGE_QUALITY)

        original_size = len(image_data)
        try:
            img = Image.open(io.BytesIO(image_data))
            orig_w, orig_h = img.size

            if orig_w > max_width or orig_h > max_height:
                ratio = min(max_width / orig_w, max_height / orig_h)
                img = img.resize(
                    (int(orig_w * ratio), int(orig_h * ratio)), Image.LANCZOS)

            if img.mode in ("RGBA", "P", "LA"):
                bg = Image.new("RGB", img.size, (255, 255, 255))
                if img.mode == "P":
                    img = img.convert("RGBA")
                bg.paste(img, mask=img.split()[-1]
                         if "A" in img.mode else None)
                img = bg
            elif img.mode != "RGB":
                img = img.convert("RGB")

            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=quality, optimize=True)
            optimized_data = buf.getvalue()

            new_w, new_h = img.size
            return {
                "data": optimized_data if len(optimized_data) < original_size else image_data,
                "original_size": original_size,
                "optimized_size": min(
                    len(optimized_data),
                    original_size),
                "tokens_before": self.estimate_tokens(
                    orig_w,
                    orig_h),
                "tokens_after": self.estimate_tokens(
                    new_w,
                    new_h),
            }
        except Exception as e:
            return {"error": str(e), "data": image_data}


# Singleton
_optimizer = None


def get_image_optimizer() -> ImageOptimizer:
    global _optimizer
    if _optimizer is None:
        _optimizer = ImageOptimizer()
    return _optimizer


def optimize_image(path: str, output: str = None) -> dict:
    """Convenience: optimize single image."""
    return get_image_optimizer().optimize(path, output)


if __name__ == "__main__":
    import sys as _sys
    if len(_sys.argv) > 1:
        result = optimize_image(
            _sys.argv[1], _sys.argv[2] if len(
                _sys.argv) > 2 else None)
        import json
        print(json.dumps(
            {k: v for k, v in result.items() if k != "data"}, indent=2))
    else:
        print("Usage: python image_optimizer.py <image_path> [output_path]")
