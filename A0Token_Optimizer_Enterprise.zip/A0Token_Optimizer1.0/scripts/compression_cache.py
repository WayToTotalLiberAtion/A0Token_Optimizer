#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Compression Result Cache (A5)
Hash-based LRU cache for deduplication. Identical inputs return
cached compressed results instantly without model invocation.
"""
import hashlib
import json
import os
import time
import threading
from collections import OrderedDict
from config import COMPRESSION_CACHE_DIR, CACHE_MAX_ENTRIES, CACHE_TTL_HOURS, CACHE_ENABLED


class CompressionCache:
    """Thread-safe LRU cache with optional disk persistence."""

    def __init__(self, max_entries=None, ttl_hours=None, persist=True):
        self.max_entries = max_entries or CACHE_MAX_ENTRIES
        self.ttl_seconds = (ttl_hours or CACHE_TTL_HOURS) * 3600
        self.persist = persist
        self._cache = OrderedDict()
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0
        self._db_path = os.path.join(COMPRESSION_CACHE_DIR, "cache_index.json")
        if persist:
            self._load_from_disk()

    @staticmethod
    def _hash_key(text: str, rate: float, profile: str) -> str:
        """Create deterministic hash from input parameters."""
        rate_str = f"{rate:.4f}" if rate is not None else "default"
        content = f"{text}|{rate_str}|{profile}"
        return hashlib.sha256(content.encode("utf-8")).hexdigest()[:32]

    def get(self, text: str, rate: float,
            profile: str = "auto") -> dict | None:
        """Lookup cached result. Returns None on miss."""
        if not CACHE_ENABLED:
            return None
        key = self._hash_key(text, rate, profile)
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                self._misses += 1
                return None
            # TTL check
            if time.time() - entry["timestamp"] > self.ttl_seconds:
                del self._cache[key]
                self._misses += 1
                return None
            # Move to end (most recently used)
            self._cache.move_to_end(key)
            self._hits += 1
            return entry["result"]

    def put(self, text: str, rate: float, profile: str, result: dict):
        """Store compression result in cache."""
        if not CACHE_ENABLED:
            return
        key = self._hash_key(text, rate, profile)
        with self._lock:
            self._cache[key] = {
                "timestamp": time.time(),
                "input_len": len(text),
                "rate": rate,
                "profile": profile,
                "result": result,
            }
            self._cache.move_to_end(key)
            # Evict oldest if over limit
            while len(self._cache) > self.max_entries:
                self._cache.popitem(last=False)
        if self.persist:
            self._save_to_disk()

    def invalidate(self, text: str = None, rate: float = None,
                   profile: str = None):
        """Invalidate specific entry or entire cache."""
        with self._lock:
            if text is not None and rate is not None:
                key = self._hash_key(text, rate, profile or "auto")
                self._cache.pop(key, None)
            else:
                self._cache.clear()
        if self.persist:
            self._save_to_disk()

    def stats(self) -> dict:
        """Return cache statistics."""
        with self._lock:
            total = self._hits + self._misses
            return {
                "entries": len(self._cache),
                "max_entries": self.max_entries,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": round(self._hits / max(total, 1) * 100, 1),
                "ttl_hours": self.ttl_seconds / 3600,
            }

    def _save_to_disk(self):
        """Persist cache index to disk (lightweight - no full text)."""
        try:
            os.makedirs(os.path.dirname(self._db_path), exist_ok=True)
            with self._lock:
                data = {}
                for key, entry in self._cache.items():
                    data[key] = {
                        "timestamp": entry["timestamp"],
                        "input_len": entry["input_len"],
                        "rate": entry["rate"],
                        "profile": entry["profile"],
                        "result": entry["result"],
                    }
            with open(self._db_path, "w") as f:
                json.dump(data, f)
        except (IOError, OSError):
            pass

    def _load_from_disk(self):
        """Load cache from disk."""
        if not os.path.exists(self._db_path):
            return
        try:
            with open(self._db_path, "r") as f:
                data = json.load(f)
            now = time.time()
            for key, entry in data.items():
                if now - entry["timestamp"] < self.ttl_seconds:
                    self._cache[key] = entry
        except (IOError, json.JSONDecodeError):
            pass


# Singleton instance
_cache_instance = None
_cache_lock = threading.Lock()


def get_cache() -> CompressionCache:
    """Get or create singleton cache instance."""
    global _cache_instance
    if _cache_instance is None:
        with _cache_lock:
            if _cache_instance is None:
                _cache_instance = CompressionCache()
    return _cache_instance
