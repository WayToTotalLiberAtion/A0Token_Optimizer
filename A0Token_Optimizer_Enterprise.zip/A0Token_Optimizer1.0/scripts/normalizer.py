#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Pre-Compression Text Normalizer (A2)
Rule-based preprocessing that removes noise BEFORE ML compression.
Typically achieves 10-30% free size reduction.
"""
import re
import unicodedata


class TextNormalizer:
    """Pipeline of normalization steps, each independently toggleable."""

    def __init__(self, profile="prose"):
        self.profile = profile
        self._build_pipeline()

    def _build_pipeline(self):
        """Build normalization steps based on content profile."""
        # All profiles get basic normalization
        self.steps = [
            ("unicode_normalize", self._unicode_normalize),
            ("collapse_whitespace", self._collapse_whitespace),
        ]
        # Code profile: minimal normalization
        if self.profile == "code":
            self.steps.append(
                ("strip_code_comments", self._strip_code_comments))
            return
        # JSON profile: minify
        if self.profile == "json":
            self.steps.append(("minify_json", self._minify_json))
            return
        # Prose/chat/docs/markdown get full pipeline
        self.steps.extend([
            ("normalize_quotes", self._normalize_quotes),
            ("normalize_dashes", self._normalize_dashes),
            ("strip_markdown_artifacts", self._strip_markdown_artifacts),
            ("deduplicate_lines", self._deduplicate_lines),
            ("strip_html_tags", self._strip_html_tags),
            ("collapse_blank_lines", self._collapse_blank_lines),
            ("strip_boilerplate", self._strip_boilerplate),
        ])

    def normalize(self, text: str) -> dict:
        """Run full normalization pipeline. Returns dict with result and stats."""
        original_len = len(text)
        step_results = []
        for name, func in self.steps:
            before = len(text)
            text = func(text)
            after = len(text)
            if before != after:
                step_results.append({"step": name, "removed": before - after})
        return {
            "text": text.strip(),
            "original_chars": original_len,
            "normalized_chars": len(text.strip()),
            "chars_removed": original_len - len(text.strip()),
            "reduction_pct": round((1 - len(text.strip()) / max(original_len, 1)) * 100, 2),
            "steps_applied": step_results,
        }

    # === Normalization Steps ===

    @staticmethod
    def _unicode_normalize(text: str) -> str:
        """Normalize Unicode to NFC form, replace fancy chars."""
        text = unicodedata.normalize("NFC", text)
        replacements = {
            "\u2018": "'", "\u2019": "'",  # curly single quotes
            "\u201c": '"', "\u201d": '"',  # curly double quotes
            "\u2013": "-", "\u2014": "--",  # en-dash, em-dash
            "\u2026": "...",               # ellipsis
            "\u00a0": " ",                 # non-breaking space
            "\u200b": "",                   # zero-width space
            "\u200e": "", "\u200f": "",     # LTR/RTL marks
            "\ufeff": "",                   # BOM
        }
        for orig, repl in replacements.items():
            text = text.replace(orig, repl)
        return text

    @staticmethod
    def _collapse_whitespace(text: str) -> str:
        """Collapse multiple spaces/tabs to single space per line."""
        lines = text.split("\n")
        return "\n".join(re.sub(r"[ \t]+", " ", line) for line in lines)

    @staticmethod
    def _normalize_quotes(text: str) -> str:
        return re.sub(r"[\u00ab\u00bb\u201a\u201b\u201e\u201f]", '"', text)

    @staticmethod
    def _normalize_dashes(text: str) -> str:
        return re.sub(r"[\u2010\u2011\u2012\u2013\u2014\u2015]", "-", text)

    @staticmethod
    def _strip_markdown_artifacts(text: str) -> str:
        """Remove decorative markdown that adds no semantic value."""
        text = re.sub(r"^#{1,6}\s*", "", text, flags=re.MULTILINE)  # headers
        text = re.sub(r"\*{3,}", "", text)      # horizontal rules ***
        text = re.sub(r"-{3,}", "", text)        # horizontal rules ---
        text = re.sub(r"={3,}", "", text)        # horizontal rules ===
        text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)  # bold
        text = re.sub(r"__(.+?)__", r"\1", text)       # bold
        text = re.sub(r"\*(.+?)\*", r"\1", text)       # italic
        text = re.sub(r"_(.+?)_", r"\1", text)         # italic
        return text

    @staticmethod
    def _deduplicate_lines(text: str) -> str:
        """Remove consecutive duplicate lines."""
        lines = text.split("\n")
        deduped = [lines[0]] if lines else []
        for line in lines[1:]:
            stripped = line.strip()
            if stripped and stripped == deduped[-1].strip(
            ) if deduped else False:
                continue
            deduped.append(line)
        return "\n".join(deduped)

    @staticmethod
    def _strip_html_tags(text: str) -> str:
        """Remove HTML tags, keep content."""
        return re.sub(r"<[^>]+>", "", text)

    @staticmethod
    def _collapse_blank_lines(text: str) -> str:
        """Collapse 3+ blank lines to 2."""
        return re.sub(r"\n{3,}", "\n\n", text)

    @staticmethod
    def _strip_boilerplate(text: str) -> str:
        """Remove common boilerplate patterns."""
        patterns = [
            r"(?i)^\s*copyright.*$",
            r"(?i)^\s*all rights reserved.*$",
            r"(?i)^\s*disclaimer:.*$",
            r"(?i)^\s*page \d+ of \d+\s*$",
        ]
        for pat in patterns:
            text = re.sub(pat, "", text, flags=re.MULTILINE)
        return text

    @staticmethod
    def _strip_code_comments(text: str) -> str:
        """Remove single-line comments from code."""
        text = re.sub(r"(?m)^\s*#[^!].*$", "", text)   # Python comments
        text = re.sub(r"(?m)^\s*//.*$", "", text)        # C-style comments
        return text

    @staticmethod
    def _minify_json(text: str) -> str:
        """Minify JSON by removing unnecessary whitespace."""
        import json as _json
        try:
            obj = _json.loads(text)
            return _json.dumps(obj, separators=(",", ":"))
        except (ValueError, TypeError):
            return re.sub(r"\s+", " ", text)


def normalize_text(text: str, profile: str = "prose") -> str:
    """Convenience: returns just the normalized text string."""
    return TextNormalizer(profile).normalize(text)["text"]


def normalize_text_detailed(text: str, profile: str = "prose") -> dict:
    """Convenience: returns full normalization result dict."""
    return TextNormalizer(profile).normalize(text)


if __name__ == "__main__":
    sample = "### Hello World\n\nThis is a test with  **bold** and *italic*.\n\n\n\nMore text."
    result = normalize_text_detailed(sample, "prose")
    print(f"Original: {result['original_chars']} chars")
    print(f"Normalized: {result['normalized_chars']} chars")
    print(
        f"Removed: {
            result['chars_removed']} chars ({
            result['reduction_pct']}%)")
    print(f"Text: {result['text']}")
