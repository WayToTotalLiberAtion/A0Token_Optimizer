#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Document Optimizer
Extracts text from documents (PDF, TXT, MD, HTML, Office),
compresses it, and optionally returns compressed text or saves to file.
Handles both input documents (sent to LLM) and output documents.
"""
import config
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


class DocumentOptimizer:
    """Extract, compress, and optimize document content."""

    TEXT_EXTENSIONS = {
        ".txt",
        ".md",
        ".markdown",
        ".rst",
        ".csv",
        ".log",
        ".yaml",
        ".yml",
        ".json",
        ".xml",
        ".html",
        ".htm"}
    PDF_EXTENSIONS = {".pdf"}
    # Office docs need extra libraries
    OFFICE_EXTENSIONS = {".docx", ".doc", ".odt", ".rt"}

    def is_enabled(self) -> bool:
        cfg = config.get_effective_config()
        return cfg.get("document_optimization", config.DOCUMENT_OPT_ENABLED)

    def extract_text(self, file_path: str) -> dict:
        """Extract text content from a document file."""
        path = Path(file_path)
        if not path.exists():
            return {"error": f"File not found: {file_path}"}

        ext = path.suffix.lower()
        original_size = path.stat().st_size

        try:
            if ext in self.TEXT_EXTENSIONS:
                text = self._extract_text_file(path)
            elif ext in self.PDF_EXTENSIONS:
                text = self._extract_pdf(path)
            elif ext in self.OFFICE_EXTENSIONS:
                text = self._extract_office(path)
            else:
                return {"error": f"Unsupported format: {ext}", "supported": list(
                    self.TEXT_EXTENSIONS | self.PDF_EXTENSIONS | self.OFFICE_EXTENSIONS)}

            return {
                "text": text,
                "file_path": str(path),
                "format": ext,
                "original_size_bytes": original_size,
                "extracted_chars": len(text),
            }
        except Exception as e:
            return {"error": f"Extraction failed: {str(e)}"}

    def _is_file_path(self, input_str: str) -> bool:
        """Detect whether input is a file path or raw text."""
        # Raw text indicators: contains newlines, very long, no file extension
        # pattern
        if "\n" in input_str or len(input_str) > 500:
            return False
        # File path indicators: starts with / or ./, has extension
        if input_str.startswith(("/", "./", "~/")
                                ) or os.path.exists(input_str):
            return True
        # Has common file extension
        ext = os.path.splitext(input_str)[1].lower()
        if ext in (self.TEXT_EXTENSIONS | self.PDF_EXTENSIONS |
                   self.OFFICE_EXTENSIONS):
            return True
        return False

    def optimize(self, file_path_or_text: str, rate: float = None,
                 output_path: str = None, direction: str = "input") -> dict:
        """Compress document or raw text. Accepts file path or text string."""
        if not self.is_enabled():
            return {
                "skipped": True,
                "reason": "Document optimization disabled"}

        # Auto-detect: file path vs raw text
        if self._is_file_path(file_path_or_text):
            extraction = self.extract_text(file_path_or_text)
            if "error" in extraction:
                return extraction
            text = extraction["text"]
            source_info = {
                "source_file": file_path_or_text,
                "source_format": extraction["format"],
                "source_size_bytes": extraction["original_size_bytes"]}
        else:
            text = file_path_or_text
            source_info = {"source": "raw_text", "source_format": "text"}

        if not text or not text.strip():
            return {"error": "No text content to optimize"}

        # Compress
        from llmlingua_core import get_optimizer
        optimizer = get_optimizer()

        if direction == "output":
            result = optimizer.compress_output(text, rate=rate)
        else:
            result = optimizer.compress_document(text, rate=rate)

        # Save compressed if output path specified
        if output_path:
            os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(result["compressed_text"])
            result["output_path"] = output_path

        result.update(source_info)
        return result

    def optimize_directory(self, dir_path: str, output_dir: str = None,
                           rate: float = None, recursive: bool = True) -> dict:
        """Optimize all documents in a directory."""
        if not self.is_enabled():
            return {
                "skipped": True,
                "reason": "Document optimization disabled"}

        results = []
        all_extensions = self.TEXT_EXTENSIONS | self.PDF_EXTENSIONS | self.OFFICE_EXTENSIONS
        dir_path = Path(dir_path)

        if not dir_path.exists():
            return {"error": f"Directory not found: {dir_path}"}

        pattern = "**/*" if recursive else "*"
        for file_path in sorted(dir_path.glob(pattern)):
            if file_path.suffix.lower() in all_extensions and file_path.is_file():
                out = None
                if output_dir:
                    rel = file_path.relative_to(dir_path)
                    out = str(
                        Path(output_dir) /
                        rel.with_suffix(".compressed.txt"))

                result = self.optimize(
                    str(file_path), rate=rate, output_path=out)
                results.append(result)

        total_orig = sum(r.get("original_chars", 0)
                         for r in results if "original_chars" in r)
        total_comp = sum(r.get("compressed_chars", 0)
                         for r in results if "compressed_chars" in r)

        return {
            "files_processed": len(results),
            "total_original_chars": total_orig,
            "total_compressed_chars": total_comp,
            "total_reduction_pct": round((1 - total_comp / max(total_orig, 1)) * 100, 2),
            "results": results,
        }

    # === Extraction Methods ===

    @staticmethod
    def _extract_text_file(path: Path) -> str:
        """Read plain text files."""
        encodings = ["utf-8", "latin-1", "cp1252", "ascii"]
        for enc in encodings:
            try:
                return path.read_text(encoding=enc)
            except (UnicodeDecodeError, UnicodeError):
                continue
        return path.read_text(encoding="utf-8", errors="replace")

    @staticmethod
    def _extract_pdf(path: Path) -> str:
        """Extract text from PDF using available libraries."""
        # Try PyPDF2 first
        try:
            import PyPDF2
            with open(path, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                pages = []
                for page in reader.pages:
                    text = page.extract_text()
                    if text:
                        pages.append(text)
                return "\n\n".join(pages)
        except ImportError:
            pass

        # Try pdfplumber
        try:
            import pdfplumber
            with pdfplumber.open(path) as pdf:
                pages = [p.extract_text() or "" for p in pdf.pages]
                return "\n\n".join(pages)
        except ImportError:
            pass

        # Try pdftotext command
        try:
            import subprocess
            result = subprocess.run(["pdftotext", str(path), "-"],
                                    capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                return result.stdout
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        return "[PDF extraction failed - install PyPDF2: pip install PyPDF2]"

    @staticmethod
    def _extract_office(path: Path) -> str:
        """Extract text from Office documents."""
        ext = path.suffix.lower()
        if ext == ".docx":
            try:
                import docx
                doc = docx.Document(str(path))
                return "\n".join(p.text for p in doc.paragraphs)
            except ImportError:
                return "[DOCX extraction failed - install python-docx: pip install python-docx]"
        elif ext == ".rt":
            try:
                import striprtf.striprtf as striprtf
                raw = path.read_text(errors="replace")
                return striprtf.rtf_to_text(raw)
            except ImportError:
                return "[RTF extraction failed - install striprtf: pip install striprtf]"
        return f"[Unsupported office format: {ext}]"

    def optimize_text(self, text: str, rate: float = None,
                      direction: str = "input") -> dict:
        """Convenience: compress raw text directly."""
        return self.optimize(text, rate=rate, direction=direction)


# Singleton
_doc_optimizer = None


def get_document_optimizer() -> DocumentOptimizer:
    global _doc_optimizer
    if _doc_optimizer is None:
        _doc_optimizer = DocumentOptimizer()
    return _doc_optimizer


def optimize_document(path: str, rate: float = None,
                      output: str = None) -> dict:
    return get_document_optimizer().optimize(path, rate=rate, output_path=output)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        r = optimize_document(
            sys.argv[1], output=sys.argv[2] if len(
                sys.argv) > 2 else None)
        import json
        print(json.dumps({k: v for k, v in r.items()
              if k != "compressed_text"}, indent=2))
    else:
        print("Usage: python document_optimizer.py <file_path> [output_path]")
