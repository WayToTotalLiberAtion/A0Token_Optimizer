import zlib
import math


def calculate_dynamic_rate(text, base_rate=0.03):
    if not text:
        return base_rate

    total_tokens = len(text.split())
    if total_tokens == 0:
        return 1.0

    # Smooth exponential decay: 1.0 for short texts, approaching base_rate for long texts
    # e.g. at 0 tokens -> 1.0, at 50 tokens -> ~0.2, at 200 tokens -> ~0.03
    smooth_rate = base_rate + (1.0 - base_rate) * \
        math.exp(-total_tokens / 30.0)

    text_bytes = text.encode("utf-8")
    compressed = zlib.compress(text_bytes)
    entropy_ratio = len(compressed) / max(1, len(text_bytes))

    # Combine smooth curve with information density (entropy)
    dynamic_rate = smooth_rate * entropy_ratio

    # Ensure absolute bounds (never compress to less than 1%, never exceed
    # 100%)
    return max(0.01, min(1.0, dynamic_rate))
