import scripts.config as config
# !/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Quality Test Suite
Tests compression quality at various rates, measures all metrics.
"""
import os
import sys
import json
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

SAMPLE_TEXTS = {
    "prose": """The European Central Bank announced today that it will maintain its current
interest rate of 4.25 percent, citing ongoing concerns about inflation in the eurozone.
President Christine Lagarde stated that while economic growth has shown signs of recovery,
the bank remains vigilant about price stability. Markets reacted positively to the decision,
with major European indices rising by approximately 1.2 percent. Analysts from Goldman Sachs
and Morgan Stanley both predicted that rates would begin to decline in the second quarter
of 2025, though the ECB has not committed to any specific timeline for rate adjustments.""",

    "code": """def fibonacci_matrix(n):
    \"\"\"Calculate the nth Fibonacci number using matrix exponentiation.
    Time complexity: O(log n), Space complexity: O(1).
    Uses the property that [[1,1],[1,0]]^n = [[F(n+1),F(n)],[F(n),F(n-1)]].
    \"\"\"'
    if n <= 1:
        return n
    def matrix_mult(A, B):
        return [
            [A[0][0]*B[0][0] + A[0][1]*B[1][0], A[0][0]*B[0][1] + A[0][1]*B[1][1]],
            [A[1][0]*B[0][0] + A[1][1]*B[1][0], A[1][0]*B[0][1] + A[1][1]*B[1][1]]
        ]
    def matrix_pow(M, p):
        result = [[1,0],[0,1]]
        while p > 0:
            if p % 2 == 1:
                result = matrix_mult(result, M)
            M = matrix_mult(M, M)
            p //= 2
        return result
    return matrix_pow([[1,1],[1,0]], n)[0][1]""",

    "chat": """User: Can you explain how Docker networking works?
Assistant: Docker provides several networking drivers. The default bridge network creates
an isolated network namespace. Containers on the same bridge can communicate via IP addresses.
The host network mode shares the host's network stack. Overlay networks enable multi-host
communication in Docker Swarm. Each container gets its own network interface and IP.
User: How do I expose ports?
Assistant: Use the -p flag: docker run -p 8080:80 maps host port 8080 to container port 80.
In docker-compose, use the ports section. EXPOSE in Dockerfile documents ports but doesn't publish them.""",

    "json_data": '{"users":[{"id":1,"name":"Alice","email":"alice@example.com","role":"admin","last_login":"2025-01-15T08:30:00Z","preferences":{"theme":"dark","language":"en","notifications":true}},{"id":2,"name":"Bob","email":"bob@example.com","role":"user","last_login":"2025-01-14T12:00:00Z","preferences":{"theme":"light","language":"de","notifications":false}}]}',
}


def run_tests():
    from llmlingua_core import get_optimizer
    from quality_reporter import QualityReporter

    optimizer = get_optimizer()
    reporter = QualityReporter()
    rates = [0.3, 0.5, 0.7, 0.9]

    print("=" * 80)
    print("A0 TOKEN OPTIMIZER v5.0 - QUALITY TEST SUITE")
    print("=" * 80)
    print(f"Model: {optimizer.get_stats().get('model_name', 'N/A')}")
    print(
        f"Adaptive compression: {
            optimizer.get_stats().get(
                'adaptive',
                'N/A')}")
    print()

    all_results = []

    for text_type, text in SAMPLE_TEXTS.items():
        print(f"\n{'─' * 60}")
        print(f"Content type: {text_type.upper()} ({len(text)} chars)")
        print(f"{'─' * 60}")

        for rate in rates:
            t0 = time.time()
            result = optimizer.compress(
                text, rate=rate, profile=text_type, direction="input")
            elapsed = time.time() - t0

            compressed = result["compressed_text"]
            quality = reporter.analyze(text, compressed)

            entry = {
                "type": text_type,
                "rate": rate,
                "original_chars": len(text),
                "compressed_chars": len(compressed),
                "reduction_pct": result.get("char_reduction_pct", 0),
                "quality_score": quality["overall_score"],
                "quality_grade": quality["quality_grade"],
                "elapsed": round(elapsed, 3),
                "profile_detected": result.get("profile", "unknown"),
                "cache_hit": result.get("cache_hit", False),
                "normalized": result.get("normalized", False),
            }
            all_results.append(entry)

            print(f"  Rate {rate:.1f}: {len(text)} → {len(compressed)} chars "
                  f"({entry['reduction_pct']}% reduction) | "
                  f"Quality: {
                quality['quality_grade']} ({
                quality['overall_score']:.3f}) | "
                f"{elapsed:.2f}s")

    # Also test output direction
    print(f"\n{'─' * 60}")
    print("OUTPUT TOKEN COMPRESSION TEST")
    print(f"{'─' * 60}")
    for text_type in ["prose", "chat"]:
        text = SAMPLE_TEXTS[text_type]
        result = optimizer.compress(text, rate=0.5, direction="output")
        quality = reporter.analyze(text, result["compressed_text"])
        print(
            f"  {text_type} [OUTPUT]: {
                len(text)} → {
                len(
                    result['compressed_text'])} chars | " f"Quality: {
                    quality['quality_grade']}")

    # Summary
    print(f"\n{'=' * 80}")
    print("SUMMARY")
    print(f"{'=' * 80}")
    avg_quality = sum(r["quality_score"]
                      for r in all_results) / len(all_results)
    avg_reduction = sum(r["reduction_pct"]
                        for r in all_results) / len(all_results)
    avg_time = sum(r["elapsed"] for r in all_results) / len(all_results)
    print(f"  Average quality score: {avg_quality:.3f}")
    print(f"  Average reduction: {avg_reduction:.1f}%")
    print(f"  Average processing time: {avg_time:.2f}s")
    print(f"  Total tests: {len(all_results)}")

    # Save results
    out_path = os.path.join(config.CACHE_DIR, "quality_test_results.json")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"\n  Full results saved: {out_path}")

    return all_results


if __name__ == "__main__":
    run_tests()
