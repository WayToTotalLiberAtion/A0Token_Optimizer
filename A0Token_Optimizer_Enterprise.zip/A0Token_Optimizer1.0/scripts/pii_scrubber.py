import re


class PIIScrubber:
    def __init__(self):
        self.patterns = {
            "EMAIL": r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+",
            "PHONE": r"\+?\d{1,3}[-.\s]?\(?\d{1,4}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}",
            "CREDIT_CARD": r"(?:\d[ -]*?){13,16}",
        }

    def scrub(self, text):
        scrubbed_text = text
        for label, pattern in self.patterns.items():
            scrubbed_text = re.sub(pattern, f"[{label}]", scrubbed_text)
        return scrubbed_text
