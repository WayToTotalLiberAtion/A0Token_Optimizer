import json
import hashlib
import os
import numpy as np
import faiss
import redis
from cryptography.fernet import Fernet


class SemanticCache:
    def __init__(self, redis_host='localhost', redis_port=6379, dimension=768):
        self.redis_client = redis.Redis(host=redis_host, port=redis_port, db=0)
        # Use HNSW for better scalability (O(log N) instead of O(N))
        self.index = faiss.IndexHNSWFlat(dimension, 32)
        self.texts = []

        # Setup symmetric encryption for cache values
        key_path = os.path.join(os.path.dirname(__file__), '.cache_key')
        if os.path.exists(key_path):
            with open(key_path, 'rb') as f:
                self.key = f.read()
        else:
            self.key = Fernet.generate_key()
            with open(key_path, 'wb') as f:
                f.write(self.key)
        self.cipher = Fernet(self.key)

    def _hash_text(self, text):
        # Fix: Use SHA-256 instead of MD5
        return hashlib.sha256(text.encode('utf-8')).hexdigest()

    def get(self, text):
        text_hash = self._hash_text(text)
        encrypted_cached = self.redis_client.get(text_hash)
        if encrypted_cached:
            try:
                # Fix: Decrypt data at rest
                decrypted = self.cipher.decrypt(encrypted_cached).decode('utf-8')
                import json
                try:
                    return json.loads(decrypted)
                except json.JSONDecodeError:
                    return decrypted
            except Exception:
                return None
        return None

    def set(self, text, compressed_text, embedding=None):
        text_hash = self._hash_text(text)
        import json
        if isinstance(compressed_text, dict):
            compressed_text = json.dumps(compressed_text)
        elif not isinstance(compressed_text, str):
            compressed_text = str(compressed_text)
        encrypted_compressed = self.cipher.encrypt(compressed_text.encode('utf-8'))
        self.redis_client.set(text_hash, encrypted_compressed)

        if embedding is not None:
            self.index.add(np.array([embedding], dtype=np.float32))
            self.texts.append(text)
