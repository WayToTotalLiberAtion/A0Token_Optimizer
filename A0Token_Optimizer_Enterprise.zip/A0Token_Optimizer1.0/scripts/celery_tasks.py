import os
import sys
from celery import Celery

# Add scripts to path
scripts_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, scripts_dir)

from llmlingua_core import get_optimizer  # noqa: E402


app = Celery(
    'batch_optimizer',
    broker='redis://localhost:6379/0',
    backend='redis://localhost:6379/0')


@app.task
def async_compress_batch(texts, rate=None):
    optimizer = get_optimizer()
    results = []
    for text in texts:
        res = optimizer.compress(text, rate=rate)
        results.append(res)
    return results
