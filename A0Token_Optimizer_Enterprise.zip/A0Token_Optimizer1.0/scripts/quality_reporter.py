#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Compression Quality Reporter (B6)
Analyzes compression quality through multiple metrics:
- Word overlap ratio
- Key entity retention
- Information density comparison
- Readability score comparison
"""
import re
from collections import Counter


class QualityReporter:
    """Analyze and report compression quality."""

    def analyze(self, original: str, compressed: str) -> dict:
        """Full quality analysis of compression result."""
        if not original or not compressed:
            return {"error": "Empty input", "overall_score": 0.0}

        metrics = {
            "word_overlap": self._word_overlap(original, compressed),
            "entity_retention": self._entity_retention(original, compressed),
            "information_density": self._information_density(original, compressed),
            "readability": self._readability_comparison(original, compressed),
            "key_phrase_retention": self._key_phrase_retention(original, compressed),
            "compression_ratio": {
                "char_ratio": round(len(compressed) / max(len(original), 1), 4),
                "word_ratio": round(
                    len(compressed.split()) / max(len(original.split()), 1), 4
                ),
            },
        }

        # Overall quality score (weighted average)
        weights = {
            "word_overlap": 0.25,
            "entity_retention": 0.30,
            "key_phrase_retention": 0.25,
            "readability_similarity": 0.20,
        }
        score = (
            metrics["word_overlap"]["score"] * weights["word_overlap"]
            + metrics["entity_retention"]["score"] *
            weights["entity_retention"]
            + metrics["key_phrase_retention"]["score"] *
            weights["key_phrase_retention"]
            + metrics["readability"]["similarity"] *
            weights["readability_similarity"]
        )

        metrics["overall_score"] = round(score, 4)
        metrics["quality_grade"] = self._score_to_grade(score)
        metrics["recommendation"] = self._get_recommendation(metrics)

        return metrics

    def _word_overlap(self, original: str, compressed: str) -> dict:
        """Measure word-level overlap between original and compressed."""
        orig_words = set(original.lower().split())
        comp_words = set(compressed.lower().split())
        if not orig_words:
            return {"score": 1.0, "retained": 0, "total": 0}

        retained = orig_words & comp_words
        score = len(retained) / len(orig_words)
        return {
            "score": round(score, 4),
            "retained": len(retained),
            "total_original": len(orig_words),
            "total_compressed": len(comp_words),
        }

    def _entity_retention(self, original: str, compressed: str) -> dict:
        """Check retention of named entities (capitalized words, numbers, etc)."""
        # Extract entities: capitalized words, numbers, emails, URLs
        entity_patterns = [
            r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b",  # Proper nouns
            r"\b\d+(?:\.\d+)?(?:%|\$|€|£)?\b",       # Numbers
            r"\b[A-Z]{2,}\b",                          # Acronyms
            r"\S+@\S+\.\S+",                           # Emails
            r"https?://\S+",                            # URLs
        ]

        orig_entities = set()
        comp_entities = set()
        for pattern in entity_patterns:
            orig_entities.update(re.findall(pattern, original))
            comp_entities.update(re.findall(pattern, compressed))

        if not orig_entities:
            return {"score": 1.0, "entities_found": 0, "retained": 0}

        retained = orig_entities & comp_entities
        lost = orig_entities - comp_entities
        score = len(retained) / len(orig_entities)

        return {
            "score": round(score, 4),
            "entities_found": len(orig_entities),
            "retained": len(retained),
            "lost": len(lost),
            "lost_entities": list(lost)[:10],  # Show up to 10
        }

    def _information_density(self, original: str, compressed: str) -> dict:
        """Compare information density (unique words / total words)."""
        def density(text):
            words = text.lower().split()
            if not words:
                return 0.0
            return len(set(words)) / len(words)

        orig_d = density(original)
        comp_d = density(compressed)
        return {
            "original_density": round(orig_d, 4),
            "compressed_density": round(comp_d, 4),
            "improvement": round(comp_d - orig_d, 4),
            "note": "Higher = more information-dense (less redundancy)",
        }

    def _readability_comparison(self, original: str, compressed: str) -> dict:
        """Compare readability scores (Flesch-like approximation)."""
        def flesch_approx(text):
            sentences = max(len(re.split(r"[.!?]+", text)), 1)
            words = text.split()
            word_count = max(len(words), 1)
            # Approximate syllables
            syllables = sum(
                max(len(re.findall(r"[aeiouy]+", w.lower())), 1) for w in words)
            score = 206.835 - 1.015 * \
                (word_count / sentences) - 84.6 * (syllables / word_count)
            return max(0, min(100, score))

        orig_score = flesch_approx(original)
        comp_score = flesch_approx(compressed)
        diff = abs(orig_score - comp_score)
        similarity = max(0, 1.0 - diff / 100)

        return {
            "original_readability": round(orig_score, 2),
            "compressed_readability": round(comp_score, 2),
            "difference": round(diff, 2),
            "similarity": round(similarity, 4),
        }

    def _key_phrase_retention(self, original: str, compressed: str) -> dict:
        """Check retention of frequently occurring meaningful phrases (bigrams)."""
        def get_bigrams(text):
            words = re.findall(r"\b\w{3,}\b", text.lower())
            return Counter(zip(words, words[1:]))

        orig_bigrams = get_bigrams(original)
        if not orig_bigrams:
            return {"score": 1.0, "key_phrases": 0}

        # Top 20 most frequent bigrams as "key phrases"
        key_phrases = set(bg for bg, _ in orig_bigrams.most_common(20))
        comp_bigrams = set(get_bigrams(compressed).keys())

        retained = key_phrases & comp_bigrams
        score = len(retained) / max(len(key_phrases), 1)

        return {
            "score": round(score, 4),
            "key_phrases": len(key_phrases),
            "retained": len(retained),
        }

    @staticmethod
    def _score_to_grade(score: float) -> str:
        if score >= 0.95:
            return "A+ (Excellent)"
        if score >= 0.90:
            return "A (Very Good)"
        if score >= 0.85:
            return "B+ (Good)"
        if score >= 0.80:
            return "B (Acceptable)"
        if score >= 0.70:
            return "C (Fair)"
        if score >= 0.60:
            return "D (Poor)"
        return "F (Unacceptable)"

    @staticmethod
    def _get_recommendation(metrics: dict) -> str:
        score = metrics["overall_score"]
        if score >= 0.90:
            return "Compression quality is excellent. Rate can potentially be increased."
        if score >= 0.80:
            return "Good quality. Current compression rate is well-balanced."
        if score >= 0.70:
            return "Fair quality. Consider reducing compression rate for better retention."
        return "Quality is below threshold. Reduce compression rate significantly."


def analyze_quality(original: str, compressed: str) -> dict:
    """Convenience function."""
    return QualityReporter().analyze(original, compressed)


if __name__ == "__main__":
    orig = "The European Central Bank announced a new interest rate of 4.25% today. President Christine Lagarde stated that inflation remains a key concern for the ECB. Markets reacted positively to the news."
    comp = "European Central Bank announced interest rate 4.25%. President Lagarde stated inflation key concern ECB. Markets reacted positively."
    import json
    print(json.dumps(analyze_quality(orig, comp), indent=2, default=str))
