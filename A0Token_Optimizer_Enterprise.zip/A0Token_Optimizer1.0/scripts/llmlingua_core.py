from entropy import calculate_dynamic_rate
import time
import threading
import logging
from llmlingua import PromptCompressor

import scripts.config as config
from scripts.metrics_tracker import get_metrics
from scripts.normalizer import normalize_text
from scripts.pii_scrubber import PIIScrubber
from scripts.entropy import calculate_dynamic_rate
from scripts.semantic_cache import SemanticCache

logger = logging.getLogger("TokenOptimizer")


class TokenOptimizer:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(TokenOptimizer, cls).__new__(cls)
                cls._instance.__init__()
            return cls._instance

    def __init__(self):
        if hasattr(self, "_initialized") and self._initialized:
            return
        self._model = None
        self._model_lock = threading.Lock()
        self._initialized = True
        self.pii_scrubber = PIIScrubber()
        self.semantic_cache = SemanticCache()

        if config.PRELOAD_MODELS:
            threading.Thread(target=self._ensure_model, daemon=True).start()

    def _ensure_model(self):
        with self._model_lock:
            if self._model is None:
                logger.info(f"Loading Extractive model: {
                        config.EXTRACTIVE_MODEL}")
                start = time.time()
                try:
                    self._model = PromptCompressor(
                        model_name=config.EXTRACTIVE_MODEL, device_map="cpu"
                    )
                    logger.info(f"Extractive model loaded in {
                            time.time() - start:.1f}s")
                except Exception as e:
                    logger.error(f"Failed to load model: {e}")
                    raise

    def compress(
        self,
        text: str,
        rate: float = None,
        profile: str = "auto",
        direction: str = "input",
    ) -> dict:
        if not text or not text.strip():
            return {
                "compressed": "",
                "original_tokens": 0,
                "compressed_tokens": 0,
                "ratio": 0.0,
                "savings": 0.0,
            }

        # 1. Semantic Cache Check
        cached_result = self.semantic_cache.get(text)
        if cached_result:
            logger.info("Semantic Cache Hit")
            return cached_result

        # 2. PII Scrubbing
        scrubbed_text = self.pii_scrubber.scrub(text)

        normalized = normalize_text(scrubbed_text)
        self._ensure_model()

        start_time = time.time()
        try:
            total_tokens = len(normalized.split())

            # Early Exit for short texts to prevent tensor errors
            if total_tokens < 50:
                logger.info("Text too short for compression, skipping.")
                out_dict = {
                    "compressed": text,
                    "original_tokens": max(1, total_tokens),
                    "compressed_tokens": max(1, total_tokens),
                    "ratio": 0.0,
                    "savings": 0,
                    "time_ms": (time.time() - start_time) * 1000,
                }
                metrics = get_metrics()
                out_dict["direction"] = direction
                metrics.record_compression(out_dict)
                self.semantic_cache.set(text, out_dict)
                return out_dict

            # 3. Dynamic Entropy Rate for longer texts
            if rate is None:
                rate = calculate_dynamic_rate(normalized)

            target = max(1, int(total_tokens * rate))

            result = self._model.compress_prompt(
                normalized.split("\n"),
                instruction="",
                question="",
                target_token=target,
                force_tokens=[],
                chunk_end_tokens=[".", "\n"],
                return_word_label=False,
                use_sentence_level_filter=True,
                use_token_level_filter=True,
                keep_first_sentence=0,
                keep_last_sentence=0,
            )

            compressed_text = result.get("compressed_prompt", "")
            orig_tokens = result.get("origin_tokens", len(text.split()))
            comp_tokens = result.get("compressed_tokens", len(compressed_text.split()))

            if orig_tokens == 0:
                orig_tokens = 1

            ratio = (orig_tokens - comp_tokens) / orig_tokens
            savings = orig_tokens - comp_tokens

            out_dict = {
                "compressed": compressed_text,
                "original_tokens": orig_tokens,
                "compressed_tokens": comp_tokens,
                "ratio": ratio,
                "savings": savings,
                "time_ms": (time.time() - start_time) * 1000,
            }

            # Update metrics
            metrics = get_metrics()
            out_dict["direction"] = direction
            metrics.record_compression(out_dict)

            # Save to semantic cache
            self.semantic_cache.set(text, out_dict)

            return out_dict

        except Exception as e:
            logger.error(f"Compression failed: {e}")
            return {
                "compressed": text,
                "original_tokens": len(text.split()),
                "compressed_tokens": len(text.split()),
                "ratio": 0.0,
                "savings": 0,
                "error": str(e),
            }


optimizer_instance = TokenOptimizer()


def get_optimizer():
    return optimizer_instance
