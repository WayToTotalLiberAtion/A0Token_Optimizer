import os

file_path = '/a0/usr/projects/skill/A0Token_Optimizer/A0Token_Optimizer1.0/scripts/llmlingua_core.py'
with open(file_path, 'r') as f:
    content = f.read()

# Fix syntax error if present
if 'normalized.split("\n' in content:
    print("Syntax error found, restoring from zip...")
    os.system('cd /a0/usr/projects/skill && unzip -o A0Token_Optimizer_Enterprise_v6.2.zip')
    with open(file_path, 'r') as f:
        content = f.read()

# Replace the try block manually
lines = content.split('\n')
out_lines = []
skip = False
for i, line in enumerate(lines):
    if 'try:' in line and 'result = self._model.compress_prompt(' in '\n'.join(lines[i:i+15]):
        out_lines.append('        target_tokens_count = max(1, int(len(normalized.split()) * rate))')
        out_lines.append('        try:')
        out_lines.append('            result = self._model.compress_prompt(')
        out_lines.append('                normalized.split("\\n"),')
        out_lines.append('                instruction="",')
        out_lines.append('                question="",')
        out_lines.append('                target_token=target_tokens_count,')
        out_lines.append('                force_tokens=[],')
        out_lines.append('                chunk_end_tokens=[],')
        out_lines.append('                return_word_label=False,')
        out_lines.append('                keep_first_sentence=False,')
        out_lines.append('                keep_last_sentence=False')
        out_lines.append('            )')
        skip = True
    elif skip and 'compressed_text = result.get' in line:
        skip = False
        out_lines.append(line)
    elif not skip:
        out_lines.append(line)

with open(file_path, 'w') as f:
    f.write('\n'.join(out_lines))
