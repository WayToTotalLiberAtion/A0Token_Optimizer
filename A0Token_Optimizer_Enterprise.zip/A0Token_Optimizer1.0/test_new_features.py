import sys
import os
import time

base_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(base_dir, "scripts"))

from llmlingua_core import get_optimizer

texts = {
    "Code_Skill": """def fetch_user_data(user_id):
    # Contact admin@company.com or call 555-123-4567 for support
    query = f"SELECT * FROM users WHERE id = {user_id}"
    result = db.execute(query)
    return result""",
    "Creative_Writing_Skill": "The crimson sun dipped below the jagged horizon, casting long, twisting shadows across the desolate wasteland. Wind howled through the canyons, whispering ancient secrets to anyone brave enough to listen.",
    "Data_Analysis_Skill": "INFO: User logged in. IP: 192.168.1.1\nINFO: User logged in. IP: 192.168.1.2\nERROR: Connection timeout on port 8080."
}

optimizer = get_optimizer()

print("\n=== Testing Core Features (PII, Entropy, Small-Model) ===")
for name, text in texts.items():
    print(f"\n--- Testing {name} ---")
    start = time.time()
    res = optimizer.compress(text)
    print(f"Original Length: {res.get('original_tokens')} tokens")
    print(f"Compressed Length: {res.get('compressed_tokens')} tokens")
    print(f"Compression Ratio: {res.get('ratio', 0):.2f}")
    print(f"Sample Output: {res.get('compressed')[:100]}...")

print("\n=== Testing Semantic Caching ===")
start = time.time()
res_cached = optimizer.compress(texts["Creative_Writing_Skill"])
duration_cached = time.time() - start
print(f"Time taken (Cached): {duration_cached:.4f}s")
