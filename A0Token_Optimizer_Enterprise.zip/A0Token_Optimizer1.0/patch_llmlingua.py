import re

with open('/a0/usr/projects/skill/A0Token_Optimizer/A0Token_Optimizer1.0/scripts/llmlingua_core.py', 'r') as f:
    content = f.read()

# We will replace target_token=0 with a dynamic calculation based on the rate
replacement = """
        target_tokens_count = max(1, int(len(normalized.split()) * rate))
        try:
            result = self._model.compress_prompt(
                normalized.split("\\n"),
                instruction="",
                question="",
                target_token=target_tokens_count,
                force_tokens=[],
                chunk_end_tokens=[],
                return_word_label=False,
                keep_first_sentence=False,
                keep_last_sentence=False
            )
"""

# Find the try block and replace it
content = re.sub(r'try:\s+# Using rate.*?\)\n', replacement, content, flags=re.DOTALL)

with open('/a0/usr/projects/skill/A0Token_Optimizer/A0Token_Optimizer1.0/scripts/llmlingua_core.py', 'w') as f:
    f.write(content)
