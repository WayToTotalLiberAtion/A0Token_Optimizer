#!/usr/bin/env python3
"""A0 Token Optimizer v5.0.0 - Centralized Configuration
All settings configurable via environment variables with TOKEN_OPT_ prefix.
Persistent user preferences stored in config file.
"""
import os
import json

# === Paths ===
BASE_DIR = os.environ.get("TOKEN_OPT_BASE_DIR", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SCRIPTS_DIR = os.path.join(BASE_DIR, "scripts")
SERVICE_DIR = os.path.join(BASE_DIR, "service")
OUTPUT_DIR = os.environ.get("TOKEN_OPT_OUTPUT_DIR", os.path.join(BASE_DIR, "output"))
CACHE_DIR = os.environ.get("TOKEN_OPT_CACHE_DIR", "/var/cache/a0-token-optimizer")
MODEL_CACHE_DIR = os.environ.get("TOKEN_OPT_MODEL_CACHE", os.path.join(CACHE_DIR, "models"))
COMPRESSION_CACHE_DIR = os.path.join(CACHE_DIR, "compression_cache")
METRICS_DIR = os.path.join(CACHE_DIR, "metrics")
CONFIG_FILE = os.path.join(CACHE_DIR, "user_config.json")
# === Model ===
MODEL_NAME = os.environ.get("TOKEN_OPT_MODEL", "microsoft/llmlingua-2-xlm-roberta-large-meetingbank")
DEVICE = os.environ.get("TOKEN_OPT_DEVICE", "cpu")
MODEL_LANG = os.environ.get("TOKEN_OPT_LANG", "en")
# === Hybrid Engine (Abstractive + Extractive) ===
HYBRID_OPT_ENABLED = os.environ.get("TOKEN_OPT_HYBRID", "true").lower() == "true"
HYBRID_MODEL = os.environ.get("TOKEN_OPT_HYBRID_MODEL", "sshleifer/distilbart-cnn-12-6")
# === Compression Defaults ===
DEFAULT_RATE = float(os.environ.get("TOKEN_OPT_RATE", "0.5"))
DEFAULT_QUALITY_THRESHOLD = float(os.environ.get("TOKEN_OPT_QUALITY_THRESHOLD", "0.85"))
ADAPTIVE_ENABLED = os.environ.get("TOKEN_OPT_ADAPTIVE", "true").lower() == "true"
ADAPTIVE_MAX_PASSES = int(os.environ.get("TOKEN_OPT_ADAPTIVE_PASSES", "3"))
ADAPTIVE_STEP = float(os.environ.get("TOKEN_OPT_ADAPTIVE_STEP", "0.05"))
# === Compression Cache ===
CACHE_ENABLED = os.environ.get("TOKEN_OPT_CACHE_ENABLED", "true").lower() == "true"
CACHE_MAX_ENTRIES = int(os.environ.get("TOKEN_OPT_CACHE_MAX", "1000"))
CACHE_TTL_HOURS = int(os.environ.get("TOKEN_OPT_CACHE_TTL", "24"))
# === Daemon ===
DAEMON_HOST = os.environ.get("TOKEN_OPT_HOST", "127.0.0.1")
DAEMON_PORT = int(os.environ.get("TOKEN_OPT_PORT", "9199"))
DAEMON_PID_FILE = os.path.join(CACHE_DIR, "daemon.pid")
# === Image Optimization ===
IMAGE_OPT_ENABLED = os.environ.get("TOKEN_OPT_IMAGE_OPT", "true").lower() == "true"
IMAGE_MAX_WIDTH = int(os.environ.get("TOKEN_OPT_IMG_MAX_W", "1024"))
IMAGE_MAX_HEIGHT = int(os.environ.get("TOKEN_OPT_IMG_MAX_H", "1024"))
IMAGE_QUALITY = int(os.environ.get("TOKEN_OPT_IMG_QUALITY", "80"))
IMAGE_FORMAT = os.environ.get("TOKEN_OPT_IMG_FORMAT", "JPEG")
# === Document Optimization ===
DOCUMENT_OPT_ENABLED = os.environ.get("TOKEN_OPT_DOC_OPT", "true").lower() == "true"
# === Output Compression ===
OUTPUT_COMPRESSION_ENABLED = os.environ.get("TOKEN_OPT_OUTPUT_COMPRESS", "true").lower() == "true"
OUTPUT_COMPRESSION_RATE = float(os.environ.get("TOKEN_OPT_OUTPUT_RATE", "0.4"))
# === Context Window Optimizer ===
CONTEXT_OPT_ENABLED = os.environ.get("TOKEN_OPT_CONTEXT_OPT", "true").lower() == "true"
CONTEXT_RECENT_KEEP = int(os.environ.get("TOKEN_OPT_CTX_RECENT", "3"))
CONTEXT_MID_RATE = float(os.environ.get("TOKEN_OPT_CTX_MID_RATE", "0.5"))
CONTEXT_OLD_RATE = float(os.environ.get("TOKEN_OPT_CTX_OLD_RATE", "0.8"))
# === Content-Type Profiles ===
PROFILES = {
    "code":          {"rate": 0.5, "normalize": False, "chunk": False, "desc": "Source code"},
    "prose":         {"rate": 0.55, "normalize": True,  "chunk": True,  "desc": "Natural language text"},
    "chat_history":  {"rate": 0.6, "normalize": True,  "chunk": True,  "desc": "Conversation logs"},
    "json":          {"rate": 0.4, "normalize": False, "chunk": False, "desc": "JSON/structured data"},
    "system_prompt": {"rate": 0.35, "normalize": False, "chunk": False, "desc": "System instructions"},
    "documentation": {"rate": 0.6, "normalize": True,  "chunk": True,  "desc": "Technical docs"},
    "markdown":      {"rate": 0.55, "normalize": True,  "chunk": True,  "desc": "Markdown content"},
    "auto":          {"rate": None, "normalize": True,  "chunk": True,  "desc": "Auto-detect"},
}
# === Metrics ===
METRICS_ENABLED = os.environ.get("TOKEN_OPT_METRICS", "true").lower() == "true"
COST_PER_1K_INPUT = float(os.environ.get("TOKEN_OPT_COST_IN", "0.01"))
COST_PER_1K_OUTPUT = float(os.environ.get("TOKEN_OPT_COST_OUT", "0.03"))
# === Quality Report ===
QUALITY_REPORT_ENABLED = os.environ.get("TOKEN_OPT_QUALITY_REPORT", "true").lower() == "true"
# === File Watcher ===
WATCH_DIR = os.environ.get("TOKEN_OPT_WATCH_DIR", os.path.join(BASE_DIR, "watch_input"))
WATCH_INTERVAL = int(os.environ.get("TOKEN_OPT_WATCH_INTERVAL", "5"))
def _ensure_dirs():
    """Create all required directories."""
    for d in [OUTPUT_DIR, CACHE_DIR, MODEL_CACHE_DIR, COMPRESSION_CACHE_DIR, METRICS_DIR, WATCH_DIR]:
        os.makedirs(d, exist_ok=True)
def load_user_config():
    """Load persistent user configuration."""
    _ensure_dirs()
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {}
def save_user_config(cfg: dict):
    """Save persistent user configuration."""
    existing = load_user_config()
    existing.update(cfg)
    with open(CONFIG_FILE, "w") as f:
        json.dump(existing, f, indent=2)
    return existing
def get_effective_config():
    """Merge env defaults with persistent user config. User config wins."""
    user_cfg = load_user_config()
    return {
        "hybrid_optimization": user_cfg.get("hybrid_optimization", HYBRID_OPT_ENABLED),
        "image_optimization": user_cfg.get("image_optimization", IMAGE_OPT_ENABLED),
        "document_optimization": user_cfg.get("document_optimization", DOCUMENT_OPT_ENABLED),
        "output_compression": user_cfg.get("output_compression", OUTPUT_COMPRESSION_ENABLED),
        "adaptive_compression": user_cfg.get("adaptive_compression", ADAPTIVE_ENABLED),
        "compression_cache": user_cfg.get("compression_cache", CACHE_ENABLED),
        "context_optimizer": user_cfg.get("context_optimizer", CONTEXT_OPT_ENABLED),
        "metrics": user_cfg.get("metrics", METRICS_ENABLED),
        "quality_reports": user_cfg.get("quality_reports", QUALITY_REPORT_ENABLED),
        "default_rate": user_cfg.get("default_rate", DEFAULT_RATE),
        "image_max_width": user_cfg.get("image_max_width", IMAGE_MAX_WIDTH),
        "image_max_height": user_cfg.get("image_max_height", IMAGE_MAX_HEIGHT),
        "image_quality": user_cfg.get("image_quality", IMAGE_QUALITY),
    }
_ensure_dirs()
PRELOAD_MODELS = True
PRELOAD_MODELS = False
EXTRACTIVE_MODEL = "microsoft/llmlingua-2-xlm-roberta-large-meetingbank"
