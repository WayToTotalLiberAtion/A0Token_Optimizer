#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - File Compressor
Compresses text files AND documents. Supports images when enabled.
"""
import os
import sys
import json
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff", ".gif"}
DOC_EXTS = {".pdf", ".docx", ".rtf", ".odt"}


def main():
    parser = argparse.ArgumentParser(description="A0 Token Optimizer - Compress File")
    parser.add_argument("input", help="Input file path")
    parser.add_argument("-o", "--output", default=None, help="Output file path")
    parser.add_argument("-r", "--rate", type=float, default=None, help="Compression rate")
    parser.add_argument("-d", "--direction", default="input", choices=["input", "output"])
    parser.add_argument("-j", "--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"Error: File not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    ext = os.path.splitext(args.input)[1].lower()
    output = args.output or os.path.splitext(args.input)[0] + "_compressed" + (ext if ext not in DOC_EXTS else ".txt")

    # Image optimization
    if ext in IMAGE_EXTS:
        from image_optimizer import get_image_optimizer
        img_opt = get_image_optimizer()
        if not img_opt.is_enabled():
            print("Image optimization is disabled. Enable in config.", file=sys.stderr)
            sys.exit(1)
        img_output = args.output or os.path.splitext(args.input)[0] + "_optimized" + ext
        result = img_opt.optimize(args.input, img_output)
        if args.json:
            print(json.dumps(result, indent=2, default=str))
        else:
            if "error" in result:
                print(f"Error: {result['error']}", file=sys.stderr)
            else:
                print(f"Image optimized: {img_output}")
                print(f"  Size: {result.get('original_size_bytes',0)} → {result.get('optimized_size_bytes',0)} bytes ({result.get('size_reduction_pct',0)}% reduction)")
                print(f"  Tokens: {result.get('original_tokens_est',0)} → {result.get('optimized_tokens_est',0)} ({result.get('tokens_saved',0)} saved)")
        return

    # Document optimization
    if ext in DOC_EXTS:
        from document_optimizer import get_document_optimizer
        doc_opt = get_document_optimizer()
        result = doc_opt.optimize(args.input, rate=args.rate, output_path=output, direction=args.direction)
        if args.json:
            print(json.dumps({k: v for k, v in result.items() if k != "compressed_text"}, indent=2, default=str))
        else:
            if "error" in result:
                print(f"Error: {result['error']}", file=sys.stderr)
            else:
                print(f"Document compressed: {output}")
                print(f"  {result.get('original_chars', 0)} → {result.get('compressed_chars', 0)} chars")
        return

    # Text file compression
    try:
        with open(args.input, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except Exception as e:
        print(f"Error reading file: {e}", file=sys.stderr)
        sys.exit(1)

    if not text.strip():
        print("Error: File is empty", file=sys.stderr)
        sys.exit(1)

    # Try daemon
    import urllib.request
    result = None
    try:
        url = f"http://{config.DAEMON_HOST}:{config.DAEMON_PORT}/compress"
        payload = json.dumps({"text": text, "rate": args.rate, "direction": args.direction}).encode()
        req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode())
    except Exception:
        from llmlingua_core import get_optimizer
        result = get_optimizer().compress(text, rate=args.rate, direction=args.direction)

    # Save
    os.makedirs(os.path.dirname(output) or ".", exist_ok=True)
    with open(output, "w", encoding="utf-8") as f:
        f.write(result["compressed_text"])

    if args.json:
        print(json.dumps({k: v for k, v in result.items() if k != "compressed_text"}, indent=2, default=str))
    else:
        orig = result.get("original_chars", len(text))
        comp = result.get("compressed_chars", 0)
        pct = result.get("char_reduction_pct", 0)
        print(f"Compressed [{args.direction.upper()}]: {args.input} → {output}")
        print(f"  {orig} → {comp} chars ({pct}% reduction)")
        if "quality" in result:
            q = result["quality"]
            print(f"  Quality: {q.get('quality_grade', 'N/A')} (score: {q.get('overall_score', 'N/A')})")


if __name__ == "__main__":
    main()
