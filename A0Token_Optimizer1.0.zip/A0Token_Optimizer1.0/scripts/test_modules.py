#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Comprehensive 13-Module Test Suite
Validates all modules function correctly end-to-end.
Usage: python3 test_modules.py
"""
import sys, os
os.chdir(os.path.dirname(os.path.abspath(__file__)) + "/..")
sys.path.insert(0, "scripts")

passed = 0; failed = 0; results = []
def test(name, fn):
    global passed, failed
    try:
        fn(); print(f"  \u2705 {name}"); passed += 1; results.append((name, True, ""))
    except Exception as e:
        print(f"  \u274c {name}: {e}"); failed += 1; results.append((name, False, str(e)))

LONG_TEXT = (
    "The rapid advancement of artificial intelligence has fundamentally "
    "transformed how businesses operate across virtually every industry sector. "
    "Machine learning algorithms now power recommendation systems, fraud detection "
    "platforms, natural language processing applications, and autonomous "
    "decision-making tools. Companies like OpenAI and Anthropic have pushed boundaries.\n\n"
    "These developments have significant implications for the global economy. "
    "According to McKinsey, AI could contribute 13 trillion dollars by 2030. "
    "The technology boosts labor productivity by approximately 40 percent.\n\n"
    "However, deployment raises ethical concerns. Issues of algorithmic bias, "
    "data privacy, and job displacement are central topics worldwide. "
    "Governments are developing regulatory frameworks for safe AI development."
)

def main():
    print("=" * 60)
    print("A0 TOKEN OPTIMIZER v5.0 - 13-MODULE TEST SUITE")
    print("=" * 60)

    def t1():
        import config; assert config.DEFAULT_RATE > 0; assert isinstance(config.get_effective_config(), dict)
    test("1.  Config", t1)

    def t2():
        from normalizer import TextNormalizer
        r = TextNormalizer("general").normalize("Hello   world   extra   spaces")
        assert isinstance(r["text"], str)
    test("2.  Normalizer", t2)

    def t3():
        from profiler import ContentProfiler
        r = ContentProfiler.get_profile("def hello(): print('hi')")
        assert r["detection"]["profile"] in ["code", "general", "prose", "chat", "data", "json"]
    test("3.  Profiler", t3)

    def t4():
        from chunker import SemanticChunker
        assert len(SemanticChunker().chunk("A.\n\nB.\n\nC.")) >= 1
    test("4.  Chunker", t4)

    def t5():
        from compression_cache import get_cache
        c = get_cache(); c.put("t", 0.5, "g", {"x": 1})
        assert c.get("t", 0.5, "g") is not None; c.invalidate("t")
    test("5.  Cache", t5)

    def t6():
        from image_optimizer import ImageOptimizer
        assert hasattr(ImageOptimizer(), "is_enabled")
    test("6.  Image Optimizer", t6)

    def t7():
        from llmlingua_core import get_optimizer
        r = get_optimizer().compress_input(LONG_TEXT, rate=0.5)
        assert len(r["compressed_text"]) > 0
    test("7.  Core INPUT", t7)

    def t8():
        from llmlingua_core import get_optimizer
        r = get_optimizer().compress_output(LONG_TEXT, rate=0.5)
        assert "compressed_text" in r
    test("8.  Core OUTPUT", t8)

    def t9():
        from metrics_tracker import get_metrics
        t = get_metrics()
        t.record_compression({"original_chars": 1000, "compressed_chars": 500,
                              "elapsed": 1.0, "direction": "input", "char_reduction_pct": 50})
        assert t.get_dashboard()["lifetime"]["total_compressions"] >= 1
    test("9.  Metrics", t9)

    def t10():
        from quality_reporter import QualityReporter
        r = QualityReporter().analyze("The cat sat on the mat", "cat sat mat")
        assert "word_overlap" in r or "overall_score" in r
    test("10. Quality Reporter", t10)

    def t11():
        from output_compressor import OutputCompressor
        r = OutputCompressor().compress_response(LONG_TEXT)
        assert "compressed_text" in r or "skipped" in r
    test("11. Output Compressor", t11)

    def t12():
        from document_optimizer import DocumentOptimizer
        r = DocumentOptimizer().optimize(LONG_TEXT)
        assert "compressed_text" in r
    test("12. Document Optimizer", t12)

    def t13():
        from context_optimizer import ContextWindowOptimizer
        r = ContextWindowOptimizer().optimize_messages([
            {"role": "user", "content": "What is ML?"},
            {"role": "assistant", "content": "ML is a subset of AI."},
        ])
        assert isinstance(r, (dict, list))
    test("13. Context Optimizer", t13)

    print()
    print("=" * 60)
    if failed == 0:
        print(f"\U0001f389 ALL {passed}/13 TESTS PASSED")
    else:
        print(f"RESULTS: {passed}/13 passed, {failed} failed")
        for n, ok, e in results:
            if not ok: print(f"  FAIL: {n}: {e}")
    print("=" * 60)
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
