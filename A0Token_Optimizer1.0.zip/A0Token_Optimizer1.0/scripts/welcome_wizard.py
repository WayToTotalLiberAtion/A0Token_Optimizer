#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Welcome Wizard
Interactive first-run setup displayed during installation.
Shows skill info and lets user configure image optimization.
Persists choices permanently to user config.
"""
import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

BANNER = r"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║     █████╗  ██████╗    ████████╗ ██████╗ ██╗  ██╗███████╗███╗   ██╗         ║
║    ██╔══██╗██╔═████╗   ╚══██╔══╝██╔═══██╗██║ ██╔╝██╔════╝████╗  ██║         ║
║    ███████║██║██╔██║      ██║   ██║   ██║█████╔╝ █████╗  ██╔██╗ ██║         ║
║    ██╔══██║████╔╝██║      ██║   ██║   ██║██╔═██╗ ██╔══╝  ██║╚██╗██║         ║
║    ██║  ██║╚██████╔╝      ██║   ╚██████╔╝██║  ██╗███████╗██║ ╚████║         ║
║    ╚═╝  ╚═╝ ╚═════╝       ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝         ║
║                                                                              ║
║           ██████╗ ██████╗ ████████╗██╗███╗   ███╗██╗███████╗███████╗██████╗  ║
║          ██╔═══██╗██╔══██╗╚══██╔══╝██║████╗ ████║██║╚══███╔╝██╔════╝██╔══██╗ ║
║          ██║   ██║██████╔╝   ██║   ██║██╔████╔██║██║  ███╔╝ █████╗  ██████╔╝ ║
║          ██║   ██║██╔═══╝    ██║   ██║██║╚██╔╝██║██║ ███╔╝  ██╔══╝  ██╔══██╗ ║
║          ╚██████╔╝██║        ██║   ██║██║ ╚═╝ ██║██║███████╗███████╗██║  ██║ ║
║           ╚═════╝ ╚═╝        ╚═╝   ╚═╝╚═╝     ╚═╝╚═╝╚══════╝╚══════╝╚═╝  ╚═╝ ║
║                                                                              ║
║                         Version 5.0.0                                        ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

INFO = """
┌──────────────────────────────────────────────────────────────────────────────┐
│                         SKILL INFORMATION                                    │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  A0 Token Optimizer - Enhanced LLMLingua2 for Agent Zero                     │
│                                                                              │
│  This skill reduces your LLM API costs by intelligently compressing          │
│  both INPUT and OUTPUT tokens while preserving meaning and quality.           │
│                                                                              │
│  ┌─ Core Features ─────────────────────────────────────────────────────┐     │
│  │                                                                     │     │
│  │  ✅ INPUT Token Compression    - Compress prompts before sending    │     │
│  │  ✅ OUTPUT Token Compression   - Compress responses for storage     │     │
│  │  ✅ Document Compression       - PDF, DOCX, TXT, MD, HTML, etc.    │     │
│  │  ✅ Image Optimization         - Reduce vision API token costs      │     │
│  │  ✅ Context Window Optimizer   - Graduated chat history compression │     │
│  │  ✅ Adaptive Multi-Pass        - Auto-tunes rate for best quality   │     │
│  │  ✅ Content-Type Profiles      - Specialized for code/prose/JSON    │     │
│  │  ✅ Pre-Compression Cleanup    - Free 10-30% reduction before ML    │     │
│  │  ✅ Smart Caching              - Instant results for repeated text  │     │
│  │  ✅ Quality Reports            - Entity retention & readability     │     │
│  │  ✅ Cost Savings Dashboard     - Track tokens & money saved         │     │
│  │  ✅ HTTP Daemon + CLI Tools    - Multiple integration options       │     │
│  │  ✅ Agent Zero Integration     - Transparent prompt interception    │     │
│  │                                                                     │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
│  Model: microsoft/llmlingua-2-xlm-roberta-large-meetingbank (~2GB)           │
│  Typical: 40-90% token reduction with 85-98% quality retention               │
│                                                                              │
│  Both directions that cost money are optimized:                              │
│  • INPUT tokens  (prompts, context, documents → sent to LLM)                 │
│  • OUTPUT tokens (responses → for storage, chaining, logging)                │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
"""

IMAGE_INFO = """
┌──────────────────────────────────────────────────────────────────────────────┐
│                      IMAGE OPTIMIZATION                                      │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  When enabled, images sent to vision models (GPT-4V, Claude Vision)          │
│  are automatically optimized to reduce token consumption:                     │
│                                                                              │
│  • Resize large images to optimal dimensions for the API                     │
│  • Recompress with quality optimization (JPEG/WebP)                          │
│  • Convert inefficient formats (BMP, TIFF → WebP)                            │
│  • Estimate and track token savings per image                                │
│                                                                              │
│  Typical savings: 30-70% fewer vision tokens per image                       │
│                                                                              │
│  ⚡ This feature is ENABLED by default.                                      │
│  You can change this setting at any time via the config API.                 │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
"""


def run_wizard(non_interactive=False, enable_images=True):
    """Run the welcome wizard. Returns config dict."""
    print(BANNER)
    print(INFO)
    print(IMAGE_INFO)

    # Default: images enabled
    image_opt = enable_images

    if not non_interactive and sys.stdin.isatty():
        print("┌──────────────────────────────────────────────────────────────────────────────┐")
        print("│                        CONFIGURATION                                         │")
        print("├──────────────────────────────────────────────────────────────────────────────┤")
        print("│                                                                              │")

        while True:
            try:
                answer = input("│  Enable image optimization? [Y/n]: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                answer = "y"
                break
            if answer in ("", "y", "yes", "j", "ja"):
                image_opt = True
                break
            elif answer in ("n", "no", "nein"):
                image_opt = False
                break
            else:
                print("│  Please answer Y (yes) or N (no).                                           │")

        print("│                                                                              │")
        if image_opt:
            print("│  ✅ Image optimization: ENABLED                                             │")
        else:
            print("│  ❌ Image optimization: DISABLED                                            │")
        print("│                                                                              │")
        print("│  You can change this later:                                                  │")
        print("│    • API: POST /config {\"image_optimization\": true/false}                    │")
        print("│    • Env: TOKEN_OPT_IMAGE_ENABLED=true/false                                  │")
        print("│    • Config: Edit user_config.json in cache dir                               │")
        print("│                                                                              │")
        print("└──────────────────────────────────────────────────────────────────────────────┘")
    else:
        if image_opt:
            print("  [Auto-config] Image optimization: ENABLED (default)")
        else:
            print("  [Auto-config] Image optimization: DISABLED")

    # Persist choice
    user_cfg = {
        "image_optimization": image_opt,
        "document_optimization": True,
        "output_compression": True,
        "adaptive_compression": True,
        "compression_cache": True,
        "context_optimizer": True,
        "metrics": True,
        "quality_reports": True,
        "wizard_completed": True,
    }
    saved = config.save_user_config(user_cfg)

    print("\n" + "=" * 78)
    print("  ✅ Configuration saved!")
    print("  ✅ A0 Token Optimizer v5.0 is ready.")
    print("=" * 78)
    print()
    print("  Quick start:")
    print(f"    • Daemon:    bash service/control.sh start")
    print(f"    • Dashboard: http://{config.DAEMON_HOST}:{config.DAEMON_PORT}/dashboard")
    print(f"    • Compress:  python3 scripts/compress.py 'Your text here'")
    print(f"    • Test:      python3 scripts/test_quality.py")
    print(f"    • File:      python3 scripts/compress_file.py document.txt")
    print()

    return saved


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="A0 Token Optimizer Welcome Wizard")
    parser.add_argument("--non-interactive", action="store_true", help="Skip prompts, use defaults")
    parser.add_argument("--no-images", action="store_true", help="Disable image optimization")
    args = parser.parse_args()
    run_wizard(non_interactive=args.non_interactive, enable_images=not args.no_images)
