#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - CLI Text Compressor
Compresses text from stdin or argument. Daemon-aware with local fallback.
Supports input AND output direction compression.
"""
import os
import sys
import json
import argparse
import urllib.request
import urllib.error

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config


def daemon_compress(text: str, rate: float, profile: str, direction: str) -> dict:
    """Try compressing via daemon HTTP API."""
    try:
        url = f"http://{config.DAEMON_HOST}:{config.DAEMON_PORT}/compress"
        payload = json.dumps({
            "text": text, "rate": rate, "profile": profile, "direction": direction
        }).encode()
        req = urllib.request.Request(
            url, data=payload,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read().decode())
    except Exception:
        return None


def local_compress(text: str, rate: float, profile: str, direction: str) -> dict:
    """Compress locally (loads model)."""
    from llmlingua_core import get_optimizer
    optimizer = get_optimizer()
    return optimizer.compress(text, rate=rate, profile=profile, direction=direction)


def main():
    parser = argparse.ArgumentParser(description="A0 Token Optimizer - Compress Text")
    parser.add_argument("text", nargs="?", default=None, help="Text to compress (or pipe via stdin)")
    parser.add_argument("-r", "--rate", type=float, default=None, help="Compression rate (0.0-1.0)")
    parser.add_argument("-p", "--profile", default="auto", help="Content profile: auto|code|prose|json|chat_history|system_prompt")
    parser.add_argument("-d", "--direction", default="input", choices=["input", "output"], help="Token direction")
    parser.add_argument("-j", "--json", action="store_true", help="Output full JSON result")
    parser.add_argument("--local", action="store_true", help="Force local mode (skip daemon)")
    args = parser.parse_args()

    # Get text
    if args.text:
        text = args.text
    elif not sys.stdin.isatty():
        text = sys.stdin.read()
    else:
        print("Usage: compress.py 'text' or echo 'text' | compress.py", file=sys.stderr)
        sys.exit(1)

    if not text.strip():
        print("Error: Empty input", file=sys.stderr)
        sys.exit(1)

    # Compress
    result = None
    if not args.local:
        result = daemon_compress(text, args.rate, args.profile, args.direction)
        if result:
            sys.stderr.write("[via daemon]\n")
    if result is None:
        sys.stderr.write("[loading local model...]\n")
        result = local_compress(text, args.rate, args.profile, args.direction)

    if args.json:
        print(json.dumps(result, indent=2, default=str))
    else:
        print(result.get("compressed_text", text))
        # Print stats to stderr
        orig = result.get("original_chars", len(text))
        comp = result.get("compressed_chars", len(result.get("compressed_text", text)))
        pct = result.get("char_reduction_pct", 0)
        d = result.get("direction", args.direction)
        sys.stderr.write(f"\n--- [{d.upper()} tokens] {orig} → {comp} chars ({pct}% reduction) ---\n")
        if "quality" in result:
            q = result["quality"]
            sys.stderr.write(f"--- Quality: {q.get('quality_grade', 'N/A')} (score: {q.get('overall_score', 'N/A')}) ---\n")


if __name__ == "__main__":
    main()
