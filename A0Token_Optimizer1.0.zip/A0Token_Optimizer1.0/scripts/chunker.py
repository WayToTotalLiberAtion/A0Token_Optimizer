#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Semantic Chunker (A4)
Splits text at natural semantic boundaries for better compression coherence.
"""
import re


class SemanticChunker:
    """Split text into semantically coherent chunks."""

    DEFAULT_MAX_CHUNK = 2000  # chars
    DEFAULT_MIN_CHUNK = 200

    def __init__(self, max_chunk_chars=None, min_chunk_chars=None):
        self.max_chunk = max_chunk_chars or self.DEFAULT_MAX_CHUNK
        self.min_chunk = min_chunk_chars or self.DEFAULT_MIN_CHUNK

    def chunk(self, text: str) -> list:
        """Split text into semantic chunks. Returns list of chunk strings."""
        if not text or len(text) <= self.max_chunk:
            return [text] if text else []

        # Try splitting by decreasing semantic strength
        chunks = self._split_by_sections(text)
        if not chunks:
            chunks = self._split_by_paragraphs(text)
        if not chunks:
            chunks = self._split_by_sentences(text)
        if not chunks:
            chunks = self._split_by_size(text)

        # Merge tiny chunks with neighbors
        chunks = self._merge_small_chunks(chunks)
        # Split oversized chunks
        chunks = self._split_large_chunks(chunks)

        return chunks

    def _split_by_sections(self, text: str) -> list:
        """Split by section headers (markdown, underlines)."""
        parts = re.split(r"\n(?=#{1,6}\s|\S+\n[=\-]{3,})", text)
        return [p.strip() for p in parts if p.strip()] if len(parts) > 1 else []

    def _split_by_paragraphs(self, text: str) -> list:
        """Split by double newlines (paragraph breaks)."""
        parts = re.split(r"\n\s*\n", text)
        return [p.strip() for p in parts if p.strip()] if len(parts) > 1 else []

    def _split_by_sentences(self, text: str) -> list:
        """Split by sentence boundaries."""
        sentences = re.split(r"(?<=[.!?])\s+(?=[A-Z])", text)
        if len(sentences) <= 1:
            return []
        # Group sentences into reasonable chunks
        chunks = []
        current = []
        current_len = 0
        for sent in sentences:
            if current_len + len(sent) > self.max_chunk and current:
                chunks.append(" ".join(current))
                current = []
                current_len = 0
            current.append(sent)
            current_len += len(sent)
        if current:
            chunks.append(" ".join(current))
        return chunks

    def _split_by_size(self, text: str) -> list:
        """Last resort: split by character count at word boundaries."""
        words = text.split()
        chunks = []
        current = []
        current_len = 0
        for word in words:
            if current_len + len(word) + 1 > self.max_chunk and current:
                chunks.append(" ".join(current))
                current = []
                current_len = 0
            current.append(word)
            current_len += len(word) + 1
        if current:
            chunks.append(" ".join(current))
        return chunks

    def _merge_small_chunks(self, chunks: list) -> list:
        """Merge chunks smaller than min_chunk with their neighbor."""
        if len(chunks) <= 1:
            return chunks
        merged = [chunks[0]]
        for chunk in chunks[1:]:
            if len(merged[-1]) < self.min_chunk or len(chunk) < self.min_chunk:
                merged[-1] = merged[-1] + "\n\n" + chunk
            else:
                merged.append(chunk)
        return merged

    def _split_large_chunks(self, chunks: list) -> list:
        """Recursively split chunks that exceed max_chunk."""
        result = []
        for chunk in chunks:
            if len(chunk) <= self.max_chunk:
                result.append(chunk)
            else:
                sub = self._split_by_size(chunk)
                result.extend(sub)
        return result


def chunk_text(text: str, max_chars: int = 2000, min_chars: int = 200) -> list:
    """Convenience function."""
    return SemanticChunker(max_chars, min_chars).chunk(text)


if __name__ == "__main__":
    sample = "\n\n".join([f"Paragraph {i}. " + "Lorem ipsum dolor sit amet. " * 20 for i in range(10)])
    chunks = chunk_text(sample)
    print(f"Input: {len(sample)} chars")
    print(f"Chunks: {len(chunks)}")
    for i, c in enumerate(chunks):
        print(f"  Chunk {i}: {len(c)} chars | {c[:60]}...")
