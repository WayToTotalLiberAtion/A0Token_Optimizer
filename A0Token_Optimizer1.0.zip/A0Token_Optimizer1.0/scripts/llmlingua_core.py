import os
import time
import threading
import logging
from llmlingua import PromptCompressor

import scripts.config as config
from scripts.metrics_tracker import get_metrics
from scripts.compression_cache import get_cache
from scripts.normalizer import normalize_text

logger = logging.getLogger("TokenOptimizer")

class TokenOptimizer:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(TokenOptimizer, cls).__new__(cls)
                cls._instance.__init__()
            return cls._instance

    def __init__(self):
        if hasattr(self, '_initialized') and self._initialized:
            return
        self._model = None
        self._model_lock = threading.Lock()
        self._initialized = True
        
        if config.PRELOAD_MODELS:
            threading.Thread(target=self._ensure_model, daemon=True).start()

    def _ensure_model(self):
        with self._model_lock:
            if self._model is None:
                logger.info(f"Loading Extractive model: {config.EXTRACTIVE_MODEL}")
                start = time.time()
                try:
                    self._model = PromptCompressor(
                        model_name=config.EXTRACTIVE_MODEL,
                        device_map="cpu"
                    )
                    logger.info(f"Extractive model loaded in {time.time() - start:.1f}s")
                except Exception as e:
                    logger.error(f"Failed to load model: {e}")
                    raise

    def compress(self, text: str, rate: float = None, profile: str = "auto", direction: str = "input") -> dict:
        if not text or not text.strip():
            return {"original_text": text, "compressed_text": text, "original_tokens": 0, "compressed_tokens": 0, "compression_ratio": "0.0%"}
            
        start_time = time.time()
        self._ensure_model()
        
        normalized_text = normalize_text(text)
        
        cache = get_cache()
        
        cached = cache.get(normalized_text, rate, profile)
        if cached:
            return cached
            
        # PURE AGGRESSIVE: Force 10% retention (90% compression) if not explicitly set higher
        rate = rate if rate is not None else 0.1
        if rate > 0.5:
            rate = 0.1
            
        try:
            result = self._model.compress_prompt(
                [normalized_text],
                ratio=rate
            )
            compressed_text = result['compressed_prompt']
            orig_tokens = result['origin_tokens']
            comp_tokens = result['compressed_tokens']
        except Exception as e:
            logger.error(f"Compression failed: {e}")
            compressed_text = normalized_text
            orig_tokens = len(normalized_text.split())
            comp_tokens = orig_tokens
            
        # Minimal safety net: if it returns literally nothing, return original
        if len(compressed_text.strip()) < 5 and len(normalized_text.strip()) > 20:
            compressed_text = normalized_text
            comp_tokens = orig_tokens
            
        ratio = f"{(1 - comp_tokens / max(1, orig_tokens)) * 100:.1f}%"
        
        final_result = {
            "original_text": text,
            "compressed_text": compressed_text,
            "original_tokens": orig_tokens,
            "compressed_tokens": comp_tokens,
            "compression_ratio": ratio,
            "elapsed": round(time.time() - start_time, 4)
        }
        
        cache.put(normalized_text, rate, profile, final_result)
        
        tracker = get_metrics()
        tracker.record_compression(final_result)
        
        return final_result
        
    def compress_input(self, text: str, rate: float = None, profile: str = "auto") -> dict:
        return self.compress(text, ratio=rate, profile=profile, direction="input")
        
    def compress_document(self, text: str, rate: float = None) -> dict:
        return self.compress(text, ratio=rate, profile="document", direction="input")

_global_instance = None
def get_optimizer():
    global _global_instance
    if _global_instance is None:
        _global_instance = TokenOptimizer()
    return _global_instance
    
def compress_input(text: str, rate: float = None) -> dict:
    return get_optimizer().compress_input(text, ratio=rate)
    
def compress_output(text: str, rate: float = None) -> dict:
    return get_optimizer().compress(text, ratio=rate, direction="output")
