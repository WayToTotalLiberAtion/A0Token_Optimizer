#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Batch Compressor
Compress all supported files in a directory. Handles text, docs, and images.
"""
import os
import sys
import json
import argparse
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

TEXT_EXTS = {".txt", ".md", ".log", ".json", ".xml", ".html", ".csv", ".yaml", ".yml"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff", ".gif"}
DOC_EXTS = {".pdf", ".docx", ".rtf"}


def main():
    parser = argparse.ArgumentParser(description="A0 Token Optimizer - Batch Compress")
    parser.add_argument("input_dir", help="Input directory")
    parser.add_argument("-o", "--output-dir", default=None, help="Output directory")
    parser.add_argument("-r", "--rate", type=float, default=None)
    parser.add_argument("-d", "--direction", default="input", choices=["input", "output"])
    parser.add_argument("--recursive", action="store_true")
    parser.add_argument("--include-images", action="store_true", help="Also optimize images")
    parser.add_argument("-j", "--json", action="store_true")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    if not input_dir.exists():
        print(f"Error: Directory not found: {input_dir}", file=sys.stderr)
        sys.exit(1)

    output_dir = Path(args.output_dir) if args.output_dir else input_dir / "compressed"
    output_dir.mkdir(parents=True, exist_ok=True)

    pattern = "**/*" if args.recursive else "*"
    all_exts = TEXT_EXTS | DOC_EXTS
    if args.include_images:
        all_exts |= IMAGE_EXTS

    files = [f for f in input_dir.glob(pattern) if f.is_file() and f.suffix.lower() in all_exts]
    print(f"Found {len(files)} files to process")

    results = []
    total_saved = 0

    for i, fpath in enumerate(files, 1):
        ext = fpath.suffix.lower()
        rel = fpath.relative_to(input_dir) if args.recursive else fpath.name
        print(f"[{i}/{len(files)}] {rel}...", end=" ", flush=True)

        try:
            if ext in IMAGE_EXTS:
                from image_optimizer import get_image_optimizer
                out = str(output_dir / (fpath.stem + "_optimized" + ext))
                result = get_image_optimizer().optimize(str(fpath), out)
                saved = result.get("tokens_saved", 0)
                print(f"Image: {result.get('size_reduction_pct', 0)}% size, {saved} tokens saved")
            elif ext in DOC_EXTS:
                from document_optimizer import get_document_optimizer
                out = str(output_dir / (fpath.stem + "_compressed.txt"))
                result = get_document_optimizer().optimize(str(fpath), rate=args.rate, output_path=out)
                saved = result.get("original_chars", 0) - result.get("compressed_chars", 0)
                print(f"Doc: {result.get('char_reduction_pct', 0)}% reduction")
            else:
                text = fpath.read_text(encoding="utf-8", errors="replace")
                if len(text.strip()) < 20:
                    print("Skipped (too small)")
                    continue
                from llmlingua_core import get_optimizer
                result = get_optimizer().compress(text, rate=args.rate, direction=args.direction)
                out = str(output_dir / (fpath.stem + "_compressed" + ext))
                Path(out).write_text(result["compressed_text"], encoding="utf-8")
                saved = result.get("original_chars", 0) - result.get("compressed_chars", 0)
                print(f"{result.get('char_reduction_pct', 0)}% reduction")

            total_saved += saved
            results.append({"file": str(rel), "saved_chars": saved})

        except Exception as e:
            print(f"Error: {e}")
            results.append({"file": str(rel), "error": str(e)})

    print(f"\n=== Batch Complete ===")
    print(f"Files processed: {len(results)}")
    print(f"Total chars saved: {total_saved:,}")
    print(f"Output: {output_dir}")

    if args.json:
        print(json.dumps({"results": results, "total_saved": total_saved}, indent=2))


if __name__ == "__main__":
    main()
