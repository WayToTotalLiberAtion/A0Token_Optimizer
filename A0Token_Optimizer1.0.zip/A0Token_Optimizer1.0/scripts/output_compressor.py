#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Output Token Compressor
Compresses LLM output/response tokens before logging, storage, or forwarding.
Reduces cost of output tokens (typically 3x more expensive than input).

Modes:
1. Post-response compression: Compress for storage/logging
2. Streaming summary: Compress streamed output chunks
3. Chain compression: Compress output before passing to next LLM call
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config


class OutputCompressor:
    """Compress LLM output tokens."""

    def __init__(self):
        self._compressor = None

    def _get_compressor(self):
        if self._compressor is None:
            from llmlingua_core import get_optimizer
            self._compressor = get_optimizer()
        return self._compressor

    def is_enabled(self) -> bool:
        cfg = config.get_effective_config()
        return cfg.get("output_compression", config.OUTPUT_COMPRESSION_ENABLED)

    def compress_response(self, response_text: str, rate: float = None,
                          profile: str = "auto") -> dict:
        """Compress an LLM response for storage or chaining."""
        if not self.is_enabled():
            return {"compressed_text": response_text, "skipped": True}

        compressor = self._get_compressor()
        return compressor.compress_output(response_text, rate=rate, profile=profile)

    def compress_for_chain(self, response_text: str, next_model_context_limit: int = 4096) -> dict:
        """Compress output before feeding to another LLM in a chain.
        Estimates tokens and compresses to fit within budget."""
        if not self.is_enabled():
            return {"compressed_text": response_text, "skipped": True}

        # Rough estimate: 1 token ~= 4 chars
        estimated_tokens = len(response_text) / 4
        if estimated_tokens <= next_model_context_limit * 0.8:
            return {"compressed_text": response_text, "skipped": True,
                    "reason": "Already within budget"}

        # Calculate needed rate
        target_chars = next_model_context_limit * 4 * 0.7  # 70% of limit
        rate = 1.0 - (target_chars / len(response_text))
        rate = max(0.2, min(0.9, rate))

        compressor = self._get_compressor()
        return compressor.compress_output(response_text, rate=rate)

    def compress_for_storage(self, response_text: str, aggressive: bool = False) -> dict:
        """Compress output for long-term storage/logging."""
        if not self.is_enabled():
            return {"compressed_text": response_text, "skipped": True}

        rate = 0.7 if aggressive else config.OUTPUT_COMPRESSION_RATE
        compressor = self._get_compressor()
        return compressor.compress_output(response_text, rate=rate)


# Singleton
_output_comp = None

def get_output_compressor() -> OutputCompressor:
    global _output_comp
    if _output_comp is None:
        _output_comp = OutputCompressor()
    return _output_comp

def compress_response(text: str, rate: float = None) -> dict:
    return get_output_compressor().compress_response(text, rate=rate)
