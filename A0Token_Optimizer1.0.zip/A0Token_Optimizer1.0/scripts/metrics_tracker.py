#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Metrics Tracker & Cost Dashboard (B2)
Persistent tracking of compression stats, token savings, and cost estimates.
"""
import os
import sys
import json
import time
import threading
from datetime import datetime, timedelta
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config


class MetricsTracker:
    """Track and persist compression metrics over time."""

    def __init__(self):
        self._lock = threading.Lock()
        self._db_path = os.path.join(config.METRICS_DIR, "metrics.json")
        self._data = self._load()

    def _load(self) -> dict:
        """Load metrics from disk."""
        os.makedirs(config.METRICS_DIR, exist_ok=True)
        if os.path.exists(self._db_path):
            try:
                with open(self._db_path, "r") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return self._empty_metrics()

    def _save(self):
        """Persist metrics to disk."""
        try:
            with open(self._db_path, "w") as f:
                json.dump(self._data, f, indent=2)
        except IOError:
            pass

    @staticmethod
    def _empty_metrics() -> dict:
        return {
            "lifetime": {
                "total_compressions": 0,
                "input_compressions": 0,
                "output_compressions": 0,
                "document_compressions": 0,
                "image_optimizations": 0,
                "total_input_tokens": 0,
                "total_output_tokens": 0,
                "total_input_tokens_saved": 0,
                "total_output_tokens_saved": 0,
                "total_chars_input": 0,
                "total_chars_output": 0,
                "total_processing_time": 0.0,
                "cache_hits": 0,
                "images_bytes_saved": 0,
                "images_tokens_saved": 0,
                "first_run": datetime.now().isoformat(),
            },
            "daily": {},
            "sessions": [],
            "current_session": None,
        }

    def record_compression(self, result: dict):
        """Record a compression event."""
        if not config.METRICS_ENABLED:
            return
        with self._lock:
            lt = self._data["lifetime"]
            direction = result.get("direction", "input")
            orig_tokens = result.get("original_tokens", 0)
            comp_tokens = result.get("compressed_tokens", 0)
            saved_tokens = orig_tokens - comp_tokens

            lt["total_compressions"] += 1
            lt["total_chars_input"] += result.get("original_chars", 0)
            lt["total_chars_output"] += result.get("compressed_chars", 0)
            lt["total_processing_time"] += result.get("elapsed", 0)

            if direction == "input":
                lt["input_compressions"] += 1
                lt["total_input_tokens"] += orig_tokens
                lt["total_input_tokens_saved"] += saved_tokens
            elif direction == "output":
                lt["output_compressions"] += 1
                lt["total_output_tokens"] += orig_tokens
                lt["total_output_tokens_saved"] += saved_tokens

            if result.get("cache_hit"):
                lt["cache_hits"] += 1

            # Daily tracking
            today = datetime.now().strftime("%Y-%m-%d")
            if today not in self._data["daily"]:
                self._data["daily"][today] = {
                    "compressions": 0, "tokens_saved": 0,
                    "input_saved": 0, "output_saved": 0,
                }
            day = self._data["daily"][today]
            day["compressions"] += 1
            day["tokens_saved"] += saved_tokens
            if direction == "input":
                day["input_saved"] += saved_tokens
            else:
                day["output_saved"] += saved_tokens

            self._save()

    def record_image_optimization(self, result: dict):
        """Record an image optimization event."""
        if not config.METRICS_ENABLED:
            return
        with self._lock:
            lt = self._data["lifetime"]
            lt["image_optimizations"] += 1
            lt["images_bytes_saved"] += result.get("original_size_bytes", 0) - result.get("optimized_size_bytes", 0)
            lt["images_tokens_saved"] += result.get("tokens_saved", 0)
            self._save()

    def record_document_compression(self):
        """Record a document compression event."""
        if not config.METRICS_ENABLED:
            return
        with self._lock:
            self._data["lifetime"]["document_compressions"] += 1
            self._save()

    def get_dashboard(self) -> dict:
        """Generate full dashboard data."""
        with self._lock:
            lt = self._data["lifetime"]
            total_tokens_saved = lt["total_input_tokens_saved"] + lt["total_output_tokens_saved"]

            # Cost estimation
            input_cost_saved = (lt["total_input_tokens_saved"] / 1000) * config.COST_PER_1K_INPUT
            output_cost_saved = (lt["total_output_tokens_saved"] / 1000) * config.COST_PER_1K_OUTPUT
            total_cost_saved = input_cost_saved + output_cost_saved

            # Daily stats for last 7 days
            recent_daily = {}
            for i in range(7):
                day = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
                recent_daily[day] = self._data["daily"].get(day, {"compressions": 0, "tokens_saved": 0})

            return {
                "lifetime": {
                    "total_compressions": lt["total_compressions"],
                    "input_compressions": lt["input_compressions"],
                    "output_compressions": lt["output_compressions"],
                    "document_compressions": lt["document_compressions"],
                    "image_optimizations": lt["image_optimizations"],
                    "total_tokens_saved": total_tokens_saved,
                    "input_tokens_saved": lt["total_input_tokens_saved"],
                    "output_tokens_saved": lt["total_output_tokens_saved"],
                    "image_tokens_saved": lt.get("images_tokens_saved", 0),
                    "total_chars_saved": lt["total_chars_input"] - lt["total_chars_output"],
                    "avg_processing_time": round(lt["total_processing_time"] / max(lt["total_compressions"], 1), 3),
                    "cache_hits": lt["cache_hits"],
                    "running_since": lt.get("first_run", "unknown"),
                },
                "cost_savings": {
                    "input_cost_saved_usd": round(input_cost_saved, 4),
                    "output_cost_saved_usd": round(output_cost_saved, 4),
                    "total_cost_saved_usd": round(total_cost_saved, 4),
                    "pricing": {
                        "input_per_1k": config.COST_PER_1K_INPUT,
                        "output_per_1k": config.COST_PER_1K_OUTPUT,
                    },
                },
                "last_7_days": recent_daily,
            }

    def get_dashboard_html(self) -> str:
        """Generate HTML dashboard."""
        d = self.get_dashboard()
        lt = d["lifetime"]
        cs = d["cost_savings"]
        html = f"""<!DOCTYPE html><html><head><title>A0 Token Optimizer Dashboard</title>
<style>body{{font-family:monospace;background:#1a1a2e;color:#eee;padding:20px}}
.card{{background:#16213e;border-radius:8px;padding:16px;margin:10px 0;border-left:4px solid #0f3460}}
.val{{font-size:24px;color:#e94560;font-weight:bold}}
.label{{color:#999;font-size:12px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}}
h1{{color:#e94560}}h2{{color:#0f3460}}
.green{{color:#4ecca3}}.red{{color:#e94560}}</style></head><body>
<h1>A0 Token Optimizer Dashboard</h1>
<div class="grid">
<div class="card"><div class="label">Total Compressions</div><div class="val">{lt['total_compressions']}</div></div>
<div class="card"><div class="label">Input Tokens Saved</div><div class="val green">{lt['input_tokens_saved']:,}</div></div>
<div class="card"><div class="label">Output Tokens Saved</div><div class="val green">{lt['output_tokens_saved']:,}</div></div>
<div class="card"><div class="label">Image Tokens Saved</div><div class="val green">{lt.get('image_tokens_saved',0):,}</div></div>
<div class="card"><div class="label">Total Cost Saved</div><div class="val green">${cs['total_cost_saved_usd']:.4f}</div></div>
<div class="card"><div class="label">Cache Hits</div><div class="val">{lt['cache_hits']}</div></div>
<div class="card"><div class="label">Avg Processing Time</div><div class="val">{lt['avg_processing_time']}s</div></div>
<div class="card"><div class="label">Documents Compressed</div><div class="val">{lt['document_compressions']}</div></div>
<div class="card"><div class="label">Images Optimized</div><div class="val">{lt['image_optimizations']}</div></div>
</div>
<h2>Last 7 Days</h2><table border=1 cellpadding=5 style="border-collapse:collapse;border-color:#333">
<tr style="color:#0f3460"><th>Date</th><th>Compressions</th><th>Tokens Saved</th></tr>"""
        for day, stats in d["last_7_days"].items():
            html += f"<tr><td>{day}</td><td>{stats['compressions']}</td><td class='green'>{stats['tokens_saved']:,}</td></tr>"
        html += "</table></body></html>"
        return html

    def reset(self):
        """Reset all metrics."""
        with self._lock:
            self._data = self._empty_metrics()
            self._save()


# Singleton
_tracker = None
_tracker_lock = threading.Lock()

def get_metrics() -> MetricsTracker:
    global _tracker
    if _tracker is None:
        with _tracker_lock:
            if _tracker is None:
                _tracker = MetricsTracker()
    return _tracker
