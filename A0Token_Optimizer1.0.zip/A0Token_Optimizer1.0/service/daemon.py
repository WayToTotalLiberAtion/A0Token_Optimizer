#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - HTTP Daemon
Serves compression API with endpoints:
  GET  /health     - Health check
  POST /compress   - Compress text (input or output)
  POST /compress/document - Compress a document
  POST /compress/image    - Optimize an image
  POST /compress/context  - Optimize conversation context
  GET  /stats      - Engine statistics
  GET  /dashboard  - HTML metrics dashboard
  GET  /config     - Current configuration
  POST /config     - Update configuration
  POST /shutdown   - Graceful shutdown
"""
import os
import sys
import json
import signal
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler

# Add scripts to path
scripts_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts")
sys.path.insert(0, scripts_dir)

import config
from llmlingua_core import get_optimizer
from metrics_tracker import get_metrics
from image_optimizer import get_image_optimizer
from document_optimizer import get_document_optimizer
from context_optimizer import get_context_optimizer
from output_compressor import get_output_compressor
from quality_reporter import QualityReporter
from compression_cache import get_cache


class TokenOptimizerHandler(BaseHTTPRequestHandler):
    """HTTP request handler for Token Optimizer daemon."""

    def log_message(self, format, *args):
        """Suppress default logging, use our own."""
        sys.stderr.write(f"[Daemon] {args[0]} {args[1]} {args[2]}\n")

    def _send_json(self, data: dict, status: int = 200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2, default=str).encode())

    def _send_html(self, html: str, status: int = 200):
        self.send_response(status)
        self.send_header("Content-Type", "text/html")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(html.encode())

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        body = self.rfile.read(length).decode("utf-8")
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            return {"raw": body}

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/health":
            opt = get_optimizer()
            self._send_json({"status": "healthy", "model_loaded": opt.is_loaded(), "version": "5.0.0"})
        elif path == "/stats":
            opt = get_optimizer()
            self._send_json({"engine": opt.get_stats(), "metrics": get_metrics().get_dashboard()})
        elif path == "/dashboard":
            html = get_metrics().get_dashboard_html()
            self._send_html(html)
        elif path == "/config":
            self._send_json(config.get_effective_config())
        else:
            self._send_json({"error": "Not found", "endpoints": [
                "GET /health", "POST /compress", "POST /compress/document",
                "POST /compress/image", "POST /compress/context",
                "GET /stats", "GET /dashboard", "GET /config", "POST /config",
                "POST /shutdown"
            ]}, 404)

    def do_POST(self):
        path = self.path.split("?")[0]
        data = self._read_body()

        if path == "/compress":
            self._handle_compress(data)
        elif path == "/compress/output":
            self._handle_compress_output(data)
        elif path == "/compress/document":
            self._handle_compress_document(data)
        elif path == "/compress/image":
            self._handle_compress_image(data)
        elif path == "/compress/context":
            self._handle_compress_context(data)
        elif path == "/config":
            self._handle_config_update(data)
        elif path == "/shutdown":
            self._send_json({"status": "shutting_down"})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
        else:
            self._send_json({"error": "Not found"}, 404)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def _handle_compress(self, data: dict):
        text = data.get("text", data.get("raw", ""))
        if not text:
            self._send_json({"error": "No text provided"}, 400)
            return
        opt = get_optimizer()
        result = opt.compress(
            text,
            rate=data.get("rate"),
            profile=data.get("profile", "auto"),
            direction=data.get("direction", "input"),
        )
        # Quality report
        if config.get_effective_config().get("quality_reports", True):
            result["quality"] = QualityReporter().analyze(text, result["compressed_text"])
        get_metrics().record_compression(result)
        self._send_json(result)

    def _handle_compress_output(self, data: dict):
        text = data.get("text", "")
        if not text:
            self._send_json({"error": "No text provided"}, 400)
            return
        comp = get_output_compressor()
        result = comp.compress_response(text, rate=data.get("rate"))
        if not result.get("skipped"):
            get_metrics().record_compression(result)
        self._send_json(result)

    def _handle_compress_document(self, data: dict):
        file_path = data.get("file_path", "")
        if not file_path:
            self._send_json({"error": "No file_path provided"}, 400)
            return
        doc_opt = get_document_optimizer()
        result = doc_opt.optimize(
            file_path,
            rate=data.get("rate"),
            output_path=data.get("output_path"),
            direction=data.get("direction", "input"),
        )
        if not result.get("skipped") and "error" not in result:
            get_metrics().record_compression(result)
            get_metrics().record_document_compression()
        self._send_json(result)

    def _handle_compress_image(self, data: dict):
        file_path = data.get("file_path", "")
        if not file_path:
            self._send_json({"error": "No file_path provided"}, 400)
            return
        img_opt = get_image_optimizer()
        result = img_opt.optimize(
            file_path,
            output_path=data.get("output_path"),
            max_width=data.get("max_width"),
            max_height=data.get("max_height"),
            quality=data.get("quality"),
        )
        if not result.get("skipped") and "error" not in result:
            get_metrics().record_image_optimization(result)
        self._send_json(result)

    def _handle_compress_context(self, data: dict):
        messages = data.get("messages", [])
        if not messages:
            self._send_json({"error": "No messages provided"}, 400)
            return
        ctx_opt = get_context_optimizer()
        result = ctx_opt.optimize_messages(
            messages,
            system_prompt=data.get("system_prompt"),
            compress_system=data.get("compress_system", False),
        )
        self._send_json(result)

    def _handle_config_update(self, data: dict):
        allowed = {
            "image_optimization", "document_optimization", "output_compression",
            "adaptive_compression", "compression_cache", "context_optimizer",
            "metrics", "quality_reports", "default_rate",
            "image_max_width", "image_max_height", "image_quality",
        }
        updates = {k: v for k, v in data.items() if k in allowed}
        if not updates:
            self._send_json({"error": "No valid config keys", "allowed": list(allowed)}, 400)
            return
        new_cfg = config.save_user_config(updates)
        self._send_json({"status": "updated", "config": new_cfg})


def run_daemon(host=None, port=None, preload=False):
    """Start the HTTP daemon."""
    host = host or config.DAEMON_HOST
    port = port or config.DAEMON_PORT

    # Write PID file
    os.makedirs(os.path.dirname(config.DAEMON_PID_FILE), exist_ok=True)
    with open(config.DAEMON_PID_FILE, "w") as f:
        f.write(str(os.getpid()))

    # Pre-load model if requested
    if preload:
        print("[Daemon] Pre-loading model...")
        get_optimizer()._ensure_model()

    server = HTTPServer((host, port), TokenOptimizerHandler)
    print(f"[Daemon] A0 Token Optimizer v5.0 listening on {host}:{port}")
    print(f"[Daemon] Dashboard: http://{host}:{port}/dashboard")
    print(f"[Daemon] PID: {os.getpid()}")

    def shutdown_handler(signum, frame):
        print(f"\n[Daemon] Received signal {signum}, shutting down...")
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, shutdown_handler)
    signal.signal(signal.SIGINT, shutdown_handler)

    try:
        server.serve_forever()
    finally:
        if os.path.exists(config.DAEMON_PID_FILE):
            os.remove(config.DAEMON_PID_FILE)
        print("[Daemon] Shutdown complete.")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="A0 Token Optimizer v5.0 Daemon")
    parser.add_argument("--host", default=None)
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--preload", action="store_true", help="Pre-load model on startup")
    args = parser.parse_args()
    run_daemon(host=args.host, port=args.port, preload=args.preload)
