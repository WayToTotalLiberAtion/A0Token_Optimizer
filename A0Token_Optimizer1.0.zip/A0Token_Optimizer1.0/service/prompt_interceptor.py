#!/usr/bin/env python3
"""A0 Token Optimizer v5.0 - Agent Zero Deep Integration (B5)
Intercepts and optimizes ALL token-consuming operations:
1. Input prompts → compress before sending to LLM
2. Output responses → compress for storage/chaining
3. Images → optimize before vision API calls
4. Documents → extract and compress content
5. Context → graduated compression for conversation history

Automatic transparent operation - A0 doesn't need to know.
"""
import os
import sys
import json
import urllib.request
import urllib.error

scripts_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts")
sys.path.insert(0, scripts_dir)

import config


class AgentZeroInterceptor:
    """Transparent optimization layer for Agent Zero."""

    def __init__(self, daemon_url=None):
        self.daemon_url = daemon_url or f"http://{config.DAEMON_HOST}:{config.DAEMON_PORT}"
        self._local_mode = False
        self._optimizer = None
        self._image_optimizer = None
        self._doc_optimizer = None
        self._ctx_optimizer = None
        self._output_compressor = None

    def _daemon_call(self, endpoint: str, data: dict) -> dict:
        """Call daemon HTTP API."""
        try:
            url = f"{self.daemon_url}{endpoint}"
            payload = json.dumps(data).encode()
            req = urllib.request.Request(
                url, data=payload,
                headers={"Content-Type": "application/json"},
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                return json.loads(resp.read().decode())
        except (urllib.error.URLError, ConnectionError, OSError):
            return None

    def _daemon_available(self) -> bool:
        try:
            url = f"{self.daemon_url}/health"
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=2) as resp:
                return resp.status == 200
        except Exception:
            return False

    def _get_local_optimizer(self):
        if self._optimizer is None:
            from llmlingua_core import get_optimizer
            self._optimizer = get_optimizer()
        return self._optimizer

    def _get_local_image_opt(self):
        if self._image_optimizer is None:
            from image_optimizer import get_image_optimizer
            self._image_optimizer = get_image_optimizer()
        return self._image_optimizer

    def _get_local_doc_opt(self):
        if self._doc_optimizer is None:
            from document_optimizer import get_document_optimizer
            self._doc_optimizer = get_document_optimizer()
        return self._doc_optimizer

    def _get_local_ctx_opt(self):
        if self._ctx_optimizer is None:
            from context_optimizer import get_context_optimizer
            self._ctx_optimizer = get_context_optimizer()
        return self._ctx_optimizer

    def _get_local_output_comp(self):
        if self._output_compressor is None:
            from output_compressor import get_output_compressor
            self._output_compressor = get_output_compressor()
        return self._output_compressor

    # === Public API ===

    def compress_input(self, text: str, rate: float = None, profile: str = "auto") -> dict:
        """Compress input/prompt text. Tries daemon first, falls back to local."""
        # Daemon attempt
        result = self._daemon_call("/compress", {
            "text": text, "rate": rate, "profile": profile, "direction": "input"
        })
        if result:
            return result
        # Local fallback
        return self._get_local_optimizer().compress_input(text, rate=rate, profile=profile)

    def compress_output(self, text: str, rate: float = None) -> dict:
        """Compress output/response text."""
        result = self._daemon_call("/compress/output", {"text": text, "rate": rate})
        if result:
            return result
        return self._get_local_output_comp().compress_response(text, rate=rate)

    def optimize_image(self, file_path: str, output_path: str = None) -> dict:
        """Optimize an image for vision API."""
        result = self._daemon_call("/compress/image", {
            "file_path": file_path, "output_path": output_path
        })
        if result:
            return result
        return self._get_local_image_opt().optimize(file_path, output_path)

    def optimize_document(self, file_path: str, rate: float = None,
                          output_path: str = None) -> dict:
        """Extract and compress document content."""
        result = self._daemon_call("/compress/document", {
            "file_path": file_path, "rate": rate, "output_path": output_path
        })
        if result:
            return result
        return self._get_local_doc_opt().optimize(file_path, rate=rate, output_path=output_path)

    def optimize_context(self, messages: list, system_prompt: str = None) -> dict:
        """Optimize conversation context with graduated compression."""
        result = self._daemon_call("/compress/context", {
            "messages": messages, "system_prompt": system_prompt
        })
        if result:
            return result
        return self._get_local_ctx_opt().optimize_messages(messages, system_prompt)

    def compress_for_agent(self, text: str, context_type: str = "auto") -> str:
        """Simple API: text in → compressed text out. For A0 integration."""
        result = self.compress_input(text, profile=context_type)
        return result.get("compressed_text", text)

    def compress_response_for_agent(self, text: str) -> str:
        """Simple API: compress LLM response. For A0 integration."""
        result = self.compress_output(text)
        return result.get("compressed_text", text)


# === Agent Zero Integration Hook ===

_interceptor = None

def get_interceptor() -> AgentZeroInterceptor:
    global _interceptor
    if _interceptor is None:
        _interceptor = AgentZeroInterceptor()
    return _interceptor

def compress_for_agent(text: str, context_type: str = "auto") -> str:
    """Drop-in function for Agent Zero prompt compression."""
    return get_interceptor().compress_for_agent(text, context_type)

def compress_response_for_agent(text: str) -> str:
    """Drop-in function for Agent Zero response compression."""
    return get_interceptor().compress_response_for_agent(text)

def optimize_image_for_agent(path: str) -> dict:
    """Drop-in function for Agent Zero image optimization."""
    return get_interceptor().optimize_image(path)

def optimize_document_for_agent(path: str) -> dict:
    """Drop-in function for Agent Zero document compression."""
    return get_interceptor().optimize_document(path)

def optimize_context_for_agent(messages: list, system_prompt: str = None) -> dict:
    """Drop-in function for Agent Zero context optimization."""
    return get_interceptor().optimize_context(messages, system_prompt)
